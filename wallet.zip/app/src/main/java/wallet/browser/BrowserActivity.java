package wallet.browser;

import android.Manifest;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.os.Handler;
import android.os.Looper;
import android.os.Environment;
import android.os.Message;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.SslErrorHandler;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.webkit.WebMessageCompat;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;
import java.util.UUID;

import wallet.main.R;
import wallet.ui.LocalizedErrors;
import wallet.ui.BaseActivity;

/** Native WebView browser with local history, bookmarks, downloads, tabs and background audio support. */
public final class BrowserActivity extends BaseActivity {
    public static final String EXTRA_URL = "browser_url";
    private static final int REQUEST_FILE = 8401;
    private static final int REQUEST_WEB_PERMISSION = 8402;
    private static final int REQUEST_GEO_PERMISSION = 8403;
    private static final int REQUEST_POST_NOTIFICATIONS = 8404;
    private static final int REQUEST_STORED_PAGE = 8405;
    private static final int MAX_HISTORY = 100;
    private static final String PREFS_SITE_PERMISSIONS = "browser_site_permissions";
    private static final int MAX_SPEECH_RETRIES = 8;
    private static final long SPEECH_RETRY_DELAY_MS = 350L;
    static final String PREFS = "browser_storage";
    static final String KEY_HISTORY = "history";
    static final String KEY_BOOKMARKS = "bookmarks";
    static final String KEY_HOME_PAGE = "home_page";
    private static final String STATE_ACTIVE_URL = "browser_active_url";
    private static final String KEY_OPEN_TABS = "open_tabs_state";

    private EditText address;
    private ProgressBar progress;
    private FrameLayout webContainer;
    private TextView status;
    private final ArrayList<BrowserTab> tabs = new ArrayList<>();
    private int activeTab = -1;
    private boolean privateMode;
    private boolean backgroundSupport;
    private BrowserTab mediaOwnerTab;
    private ValueCallback<Uri[]> fileChooserCallback;
    private PermissionRequest pendingPermissionRequest;
    private String[] pendingWebResources;
    private String pendingWebPermissionOrigin;
    private AlertDialog pendingWebPermissionDialog;
    private SpeechRecognizer speechRecognizer;
    private WebView speechOwnerWebView;
    private String speechSessionId;
    private String speechSessionToken;
    private Intent speechRecognitionIntent;
    private int speechRetryCount;
    private boolean speechStopRequested;
    private boolean speechStartEventSent;
    private Runnable speechRetryRunnable;
    private GeolocationPermissions.Callback pendingGeoCallback;
    private String pendingGeoOrigin;
    private BroadcastReceiver mediaCommandReceiver;
    private View browserRoot;
    private View fullscreenView;
    private WebChromeClient.CustomViewCallback fullscreenCallback;
    private int savedSystemUiVisibility;
    private final Handler mediaStateHandler = new Handler(Looper.getMainLooper());
    private boolean lastObservedMediaPlaying;
    // Set only after the user explicitly enables background playback and leaves the browser.
    private boolean activityInBackground;
    private boolean backgroundPlaybackDesired;
    private long mediaProbeGeneration;
    private final Runnable mediaProbeWatchdog = new Runnable() {
        @Override public void run() {
            // Invalidate any late callback from a probe that timed out.
            mediaProbeGeneration++;
            // If WebView stops answering while backgrounded, do not leave a stale PLAYING state.
            publishMediaState(false);
        }
    };
    private final Runnable mediaStatePoll = new Runnable() {
        @Override public void run() {
            if (!backgroundSupport || isFinishing()) return;
            WebView web = mediaOwnerTab == null ? currentWebView() : mediaOwnerTab.webView;
            if (web == null) {
                publishMediaState(false);
                mediaStateHandler.postDelayed(this, 5000L);
                return;
            }
            try {
                web.evaluateJavascript(buildMediaStateProbe(),
                        value -> {
                            if (!backgroundSupport || isFinishing()) return;
                            boolean ended = "\"E\"".equals(value) || "E".equals(value);
                            boolean playingNow = "1".equals(value) || "\"1\"".equals(value);
                            if (ended) {
                                backgroundPlaybackDesired = false;
                                publishMediaState(false);
                            } else {
                                // Never keep a stale PLAYING state when the media element is paused.
                                publishMediaState(playingNow);
                            }
                            mediaStateHandler.postDelayed(mediaStatePoll,
                                    !playingNow && activityInBackground && backgroundPlaybackDesired ? 2000L : 5000L);
                        });
            } catch (RuntimeException ignored) {
                mediaStateHandler.postDelayed(this, 5000L);
            }
        }
    };

    private static final class BrowserTab {
        final WebView webView;
        final String speechBridgeToken;
        androidx.webkit.ScriptHandler speechDocumentStartScript;
        String title;
        String url;
        BrowserTab(WebView webView, String speechBridgeToken) {
            this.webView = webView;
            this.speechBridgeToken = speechBridgeToken;
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        BrowserTab tab = currentTab();
        if (tab != null) {
            String activeUrl = tab.webView.getUrl();
            if (isWebUrl(activeUrl)) outState.putString(STATE_ACTIVE_URL, activeUrl);
        }
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        String requestedUrl = intent == null ? null : intent.getStringExtra(EXTRA_URL);
        if (requestedUrl != null && !requestedUrl.trim().isEmpty()) navigate(requestedUrl);
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_browser);
        // Match the app-wide system bar surfaces; the browser toolbar alone uses colorPrimary.
        android.util.TypedValue systemSurface = new android.util.TypedValue();
        if (getTheme().resolveAttribute(android.R.attr.colorBackground, systemSurface, true)) {
            int surfaceColor = systemSurface.resourceId != 0
                    ? androidx.core.content.ContextCompat.getColor(this, systemSurface.resourceId)
                    : systemSurface.data;
            getWindow().setStatusBarColor(surfaceColor);
            getWindow().setNavigationBarColor(surfaceColor);
        }
        browserRoot = findViewById(R.id.browserRoot);
        setTitle(R.string.browser_title);
        address = findViewById(R.id.browserAddress);
        progress = findViewById(R.id.browserProgress);
        webContainer = findViewById(R.id.browserWebContainer);
        status = findViewById(R.id.browserStatus);

        findViewById(R.id.browserWallet).setOnClickListener(v -> returnToMainWallet());
        findViewById(R.id.browserHome).setOnClickListener(v -> loadHome());
        findViewById(R.id.browserShare).setOnClickListener(v -> shareCurrentPage());
        findViewById(R.id.browserTabs).setOnClickListener(v -> showTabs());
        findViewById(R.id.browserMenu).setOnClickListener(this::showBrowserMenu);
        address.setOnEditorActionListener((view, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE
                    || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER
                    && event.getAction() == KeyEvent.ACTION_DOWN)) {
                navigateFromAddress();
                return true;
            }
            return false;
        });

        registerMediaReceiver();
        String restoredUrl = state == null ? null : state.getString(STATE_ACTIVE_URL);
        String initialUrl = getIntent() == null ? null : getIntent().getStringExtra(EXTRA_URL);
        boolean restoredTabs = false;
        if (initialUrl == null || initialUrl.trim().isEmpty()) {
            restoredTabs = restoreOpenTabs();
        }
        if (!restoredTabs) {
            createTab(null, true);
            if (restoredUrl != null && isWebUrl(restoredUrl)) {
                navigate(restoredUrl);
            } else if (initialUrl != null && !initialUrl.trim().isEmpty()) {
                navigate(initialUrl);
            } else {
                loadHome();
            }
        } else if (restoredUrl != null && isWebUrl(restoredUrl) && state != null) {
            navigate(restoredUrl);
        }
        updateBrowserControls();
    }

    /**
     * Probes HTML media and, only after the user opted into background playback and the
     * Activity left the foreground, keeps common HTML5 players from treating the browser
     * background transition as an instruction to pause.
     */
    private void installMediaStateListeners(WebView view) {
        if (view == null) return;
        String script = "(function(){"
                + "if(window.__browserListenersInstalled)return;"
                + "window.__browserListenersInstalled=true;"
                + "function reportMedia(){var a=Array.prototype.slice.call(document.querySelectorAll('video,audio'));"
                + "var p=a.some(function(m){return !m.paused&&!m.ended;});"
                + "try{if(window.BrowserMediaBridge)window.BrowserMediaBridge.onMediaStateChanged(p);}catch(e){}}"
                + "function reportPage(){try{if(window.BrowserMediaBridge)window.BrowserMediaBridge.onPageChanged(document.title||location.href,location.href);}catch(e){}}"
                + "['play','playing','pause','ended','emptied','waiting','stalled','error'].forEach(function(ev){"
                + "document.addEventListener(ev,function(e){if(e.target&&(e.target.tagName==='VIDEO'||e.target.tagName==='AUDIO'))reportMedia();},true);});"
                + "['pushState','replaceState'].forEach(function(k){var original=history[k];history[k]=function(){var r=original.apply(this,arguments);setTimeout(reportPage,0);return r;};});"
                + "window.addEventListener('popstate',reportPage,true);window.addEventListener('hashchange',reportPage,true);"
                + "try{new MutationObserver(reportPage).observe(document.documentElement,{childList:true,subtree:true,characterData:true});}catch(e){}"
                + "document.addEventListener('visibilitychange',reportMedia,true);reportPage();reportMedia();})();";
        try { view.evaluateJavascript(script, null); } catch (RuntimeException ignored) { }
    }

    private String buildMediaStateProbe() {
        // Wait for play() promises to settle before reporting media state. Checking
        // immediately after play() often reports paused=true and leaves stale UI state.
        String attemptPlay = activityInBackground && backgroundPlaybackDesired ? "true" : "false";
        return "(function(){var m=Array.prototype.slice.call(document.querySelectorAll('video,audio'));"
                + "if(!m.length)return '0';var resume=" + attemptPlay + ";"
                + "var attempts=resume?Promise.all(m.map(function(x){if(x.ended||!x.paused)return Promise.resolve();"
                + "try{x.setAttribute('playsinline','');x.setAttribute('webkit-playsinline','');"
                + "var p=x.play();return p&&p.catch?p.catch(function(){return null;}):Promise.resolve();}"
                + "catch(e){return Promise.resolve();}})):Promise.resolve();"
                + "return attempts.then(function(){return new Promise(function(resolve){setTimeout(function(){"
                + "var active=m.some(function(x){return !x.paused&&!x.ended;});"
                + "var ended=m.every(function(x){return x.ended;});resolve(active?'1':(ended?'E':'0'));"
                + "},700);});});})()";
    }

    private void reinforceBackgroundPlayback() {
        if (!backgroundSupport || !backgroundPlaybackDesired) return;
        BrowserTab tab = mediaOwnerTab == null ? currentTab() : mediaOwnerTab;
        if (tab == null) return;
        try { tab.webView.evaluateJavascript(buildMediaStateProbe(), null); }
        catch (RuntimeException ignored) { }
    }

    private void setBackgroundMediaPlaybackPolicy(boolean enabled) {
        BrowserTab tab = mediaOwnerTab == null ? currentTab() : mediaOwnerTab;
        if (tab == null) return;
        try {
            // Relax the gesture gate only while the user has explicitly enabled the
            // browser's background-media mode; restore the normal WebView policy on stop.
            tab.webView.getSettings().setMediaPlaybackRequiresUserGesture(!enabled);
        } catch (RuntimeException ignored) { }
    }

    private void registerMediaReceiver() {
        mediaCommandReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                String action = intent == null ? null : intent.getAction();
                String script;
                if (BrowserPlaybackService.ACTION_MEDIA_PLAY.equals(action)) {
                    script = "document.querySelectorAll('video,audio').forEach(function(m){try{m.play().catch(function(){});}catch(e){}});";
                } else if (BrowserPlaybackService.ACTION_MEDIA_PAUSE.equals(action)
                        || BrowserPlaybackService.ACTION_MEDIA_STOP.equals(action)) {
                    script = "document.querySelectorAll('video,audio').forEach(function(m){try{m.pause();}catch(e){}});";
                } else {
                    return;
                }
                BrowserTab target = mediaOwnerTab == null ? currentTab() : mediaOwnerTab;
                if (target != null) {
                    try { target.webView.evaluateJavascript(script, null); } catch (RuntimeException ignored) { }
                }
                if (BrowserPlaybackService.ACTION_MEDIA_STOP.equals(action)) {
                    setBackgroundMediaPlaybackPolicy(false);
                    backgroundSupport = false;
                    backgroundPlaybackDesired = false;
                    lastObservedMediaPlaying = false;
                    mediaStateHandler.removeCallbacks(mediaStatePoll);
                    mediaOwnerTab = null;
                    updateBrowserControls();
                } else if (BrowserPlaybackService.ACTION_MEDIA_PLAY.equals(action)) {
                    backgroundPlaybackDesired = true;
                    // State is published only after the WebView confirms actual playback.
                    reinforceBackgroundPlayback();
                } else if (BrowserPlaybackService.ACTION_MEDIA_PAUSE.equals(action)) {
                    backgroundPlaybackDesired = false;
                    lastObservedMediaPlaying = false;
                }
            }
        };
        IntentFilter filter = new IntentFilter();
        filter.addAction(BrowserPlaybackService.ACTION_MEDIA_PLAY);
        filter.addAction(BrowserPlaybackService.ACTION_MEDIA_PAUSE);
        filter.addAction(BrowserPlaybackService.ACTION_MEDIA_STOP);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(mediaCommandReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(mediaCommandReceiver, filter);
        }
    }

    private void createTab(String url, boolean activate) {
        WebView webView = new WebView(this);
        // about:blank has no page stylesheet, so use the active app theme surface
        // as the WebView canvas. Normal web pages continue to render their own backgrounds.
        android.util.TypedValue blankSurface = new android.util.TypedValue();
        if (getTheme().resolveAttribute(android.R.attr.colorBackground, blankSurface, true)) {
            int blankColor = blankSurface.resourceId != 0
                    ? androidx.core.content.ContextCompat.getColor(this, blankSurface.resourceId)
                    : blankSurface.data;
            webView.setBackgroundColor(blankColor);
        }
        WebSettings settings = webView.getSettings();
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, !privateMode);
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(true);
        settings.setMediaPlaybackRequiresUserGesture(true);
        // Push HTML media state changes immediately instead of relying only on polling.
        // Events are emitted by the page's media elements and forwarded to the native service.
        final String speechBridgeToken = UUID.randomUUID().toString();
        webView.addJavascriptInterface(new Object() {
            @android.webkit.JavascriptInterface
            public void onMediaStateChanged(boolean playing) {
                runOnUiThread(() -> {
                    if (!backgroundSupport || isFinishing()) return;
                    BrowserTab owner = mediaOwnerTab;
                    if (owner != null && owner.webView == webView) {
                        if (!playing) backgroundPlaybackDesired = false;
                        publishMediaState(playing);
                    }
                });
            }
            @android.webkit.JavascriptInterface
            public void onPageChanged(String pageTitle, String pageUrl) {
                runOnUiThread(() -> {
                    if (isFinishing() || privateMode || !isWebUrl(pageUrl)) return;
                    BrowserTab owner = null;
                    for (BrowserTab candidate : tabs) {
                        if (candidate.webView == webView) { owner = candidate; break; }
                    }
                    if (owner == null) return;
                    owner.url = pageUrl;
                    owner.title = pageTitle == null || pageTitle.trim().isEmpty() ? pageUrl : pageTitle;
                    saveHistory(owner.title, pageUrl);
                    persistOpenTabs();
                    if (owner == currentTab()) {
                        address.setText(pageUrl);
                        status.setText(owner.title);
                    }
                });
            }
        }, "BrowserMediaBridge");
        boolean webMessageSpeechBridgeInstalled = false;
        java.util.Set<String> speechAllowedOrigins = new java.util.HashSet<>(
                java.util.Arrays.asList("https://youtube.com", "https://*.youtube.com"));
        if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            try {
                WebViewCompat.addWebMessageListener(webView, "BrowserSpeechBridge",
                        speechAllowedOrigins,
                        (view, message, sourceOrigin, isMainFrame, replyProxy) ->
                                handleNativeSpeechMessage(view, speechBridgeToken,
                                        message, sourceOrigin, isMainFrame));
                webMessageSpeechBridgeInstalled = true;
            } catch (RuntimeException ignored) {
                webMessageSpeechBridgeInstalled = false;
            }
        }
        if (!webMessageSpeechBridgeInstalled) {
            webView.addJavascriptInterface(new BrowserSpeechBridge(webView, speechBridgeToken),
                    "BrowserSpeechBridge");
        }

        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSafeBrowsingEnabled(true);
        settings.setGeolocationEnabled(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(true);
        settings.setDefaultTextEncodingName("UTF-8");

        BrowserTab tab = new BrowserTab(webView, speechBridgeToken);
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            try {
                tab.speechDocumentStartScript = WebViewCompat.addDocumentStartJavaScript(
                        webView,
                        buildSpeechRecognitionBridgeScript(tab.speechBridgeToken),
                        speechAllowedOrigins);
            } catch (RuntimeException ignored) {
                tab.speechDocumentStartScript = null;
            }
        }
        tabs.add(tab);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return routeUrl(request.getUrl(), request.isForMainFrame());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return routeUrl(Uri.parse(url), true);
            }
            @Override public void onPageStarted(WebView view, String url, Bitmap favicon) {
                cancelSpeechRecognitionForWebView(view);
                tab.url = url;
                persistOpenTabs();
                if (currentTab() == tab) {
                    address.setText(url);
                    progress.setProgress(0);
                    progress.setVisibility(View.VISIBLE);
                    status.setText(R.string.browser_loading);
                    updateBrowserControls();
                }
            }
            @Override public void onPageFinished(WebView view, String url) {
                installMediaStateListeners(view);
                installWebPermissionStatusCompatibility(view);
                installSpeechRecognitionBridge(view, tab.speechBridgeToken);
                tab.url = url;
                String title = view.getTitle();
                tab.title = title == null || title.trim().isEmpty() ? url : title;
                if (tabs.get(activeTab < 0 ? 0 : activeTab) == tab) {
                    address.setText(url);
                    status.setText(tab.title);
                }
                if (!privateMode && isWebUrl(url)) saveHistory(tab.title, url);
                persistOpenTabs();
                if (backgroundSupport) updatePlaybackServicePage();
                updateBrowserControls();
            }
            @Override public void onReceivedSslError(WebView view, SslErrorHandler handler,
                    android.net.http.SslError error) {
                handler.cancel();
                runOnUiThread(() -> Toast.makeText(BrowserActivity.this,
                        R.string.browser_security_warning, Toast.LENGTH_LONG).show());
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request,
                    android.webkit.WebResourceError error) {
                if (request.isForMainFrame() && currentTab() == tab) status.setText(error.getDescription());
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int newProgress) {
                if (newProgress < 100) installSpeechRecognitionBridge(view, tab.speechBridgeToken);
                if (tabs.get(activeTab < 0 ? 0 : activeTab) == tab) {
                    progress.setProgress(newProgress);
                    progress.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
                }
            }
            @Override public void onReceivedIcon(WebView view, Bitmap icon) {
                if (icon == null || privateMode) return;
                String pageUrl = view.getUrl();
                if (pageUrl == null) return;
                String host = Uri.parse(pageUrl).getHost();
                if (host == null || host.isEmpty()) return;
                try {
                    int width = Math.max(1, icon.getWidth());
                    int height = Math.max(1, icon.getHeight());
                    float scale = Math.min(1f, Math.min(48f / width, 48f / height));
                    Bitmap compact = scale < 1f ? Bitmap.createScaledBitmap(icon,
                            Math.max(1, Math.round(width * scale)),
                            Math.max(1, Math.round(height * scale)), true) : icon;
                    ByteArrayOutputStream output = new ByteArrayOutputStream();
                    if (!compact.compress(Bitmap.CompressFormat.PNG, 100, output)) return;
                    byte[] data = output.toByteArray();
                    if (data.length <= 32768) {
                        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                                .putString("favicon_" + host.toLowerCase(Locale.ROOT),
                                        Base64.encodeToString(data, Base64.NO_WRAP))
                                .apply();
                    }
                } catch (RuntimeException ignored) { }
            }

            @Override public void onReceivedTitle(WebView view, String title) {
                tab.title = title;
                if (tabs.get(activeTab < 0 ? 0 : activeTab) == tab) {
                    setTitle(title == null || title.trim().isEmpty() ? getString(R.string.browser_title) : title);
                    status.setText(title == null ? "" : title);
                    if (backgroundSupport) updatePlaybackServicePage();
                }
            }
            @Override public boolean onShowFileChooser(WebView webView,
                    ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
                fileChooserCallback = filePathCallback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                if (fileChooserParams != null && fileChooserParams.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                }
                try {
                    startActivityForResult(Intent.createChooser(intent, getString(R.string.browser_title)), REQUEST_FILE);
                } catch (ActivityNotFoundException ex) {
                    fileChooserCallback = null;
                    filePathCallback.onReceiveValue(null);
                    return false;
                }
                return true;
            }
            @Override public boolean onCreateWindow(WebView view, boolean isDialog,
                    boolean isUserGesture, Message resultMsg) {
                if (!isUserGesture) return false;
                createTab(null, true);
                BrowserTab newTab = tabs.get(tabs.size() - 1);
                WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
                transport.setWebView(newTab.webView);
                resultMsg.sendToTarget();
                return true;
            }
            @Override public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> requestWebPermission(request));
            }
            @Override public void onPermissionRequestCanceled(PermissionRequest request) {
                runOnUiThread(() -> cancelPendingWebPermission(request));
            }
            @Override public void onGeolocationPermissionsShowPrompt(String origin,
                    GeolocationPermissions.Callback callback) {
                runOnUiThread(() -> requestGeolocation(origin, callback));
            }
            @Override public void onGeolocationPermissionsHidePrompt() {
                pendingGeoCallback = null;
                pendingGeoOrigin = null;
            }
            @Override public void onShowCustomView(View view, CustomViewCallback callback) {
                enterFullscreen(view, callback);
            }
            @Override public void onHideCustomView() {
                exitFullscreen();
            }
        });
        webView.setDownloadListener((downloadUrl, userAgent, contentDisposition, mimeType, contentLength) ->
                downloadFile(tab.webView, downloadUrl, userAgent, contentDisposition, mimeType));
        if (activate) switchToTab(tabs.size() - 1);
        if (url != null && isWebUrl(url)) webView.loadUrl(url);
    }

    private boolean routeUrl(Uri uri, boolean mainFrame) {
        if (uri == null || uri.getScheme() == null) return true;
        String scheme = uri.getScheme().toLowerCase(Locale.ROOT);
        if ("http".equals(scheme) || "https".equals(scheme)) return false;
        if ("about".equals(scheme) && "blank".equalsIgnoreCase(uri.getLastPathSegment())) return false;
        if (!mainFrame) return true;
        if ("bitcoin".equals(scheme)) {
            try {
                Intent send = new Intent(Intent.ACTION_VIEW, uri);
                send.setClassName(this, "wallet.send.SendActivity");
                startActivity(send);
            } catch (RuntimeException ex) {
                Toast.makeText(this, R.string.browser_external_open_failed, Toast.LENGTH_SHORT).show();
            }
            return true;
        }
        if ("intent".equals(scheme) || "javascript".equals(scheme) || "file".equals(scheme)
                || "content".equals(scheme) || "data".equals(scheme) || "blob".equals(scheme)) {
            return true;
        }
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (ActivityNotFoundException | SecurityException ex) {
            Toast.makeText(this, R.string.browser_external_open_failed, Toast.LENGTH_SHORT).show();
        }
        return true;
    }

    private static boolean isWebUrl(String raw) {
        if (raw == null) return false;
        String value = raw.toLowerCase(Locale.ROOT);
        return value.startsWith("http://") || value.startsWith("https://");
    }

    private WebView currentWebView() {
        if (activeTab < 0 || activeTab >= tabs.size()) return null;
        return tabs.get(activeTab).webView;
    }

    private BrowserTab currentTab() {
        if (activeTab < 0 || activeTab >= tabs.size()) return null;
        return tabs.get(activeTab);
    }

    private void switchToTab(int index) {
        if (index < 0 || index >= tabs.size()) return;
        webContainer.removeAllViews();
        activeTab = index;
        BrowserTab tab = tabs.get(index);
        if (tab.webView.getParent() instanceof ViewGroup) {
            ((ViewGroup) tab.webView.getParent()).removeView(tab.webView);
        }
        webContainer.addView(tab.webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        address.setText(tab.url == null ? "" : tab.url);
        setTitle(tab.title == null ? getString(R.string.browser_title) : tab.title);
        status.setText(tab.title == null ? getString(R.string.browser_ready) : tab.title);
        updateBrowserControls();
        if (backgroundSupport && mediaOwnerTab == null) mediaOwnerTab = tab;
        if (backgroundSupport) updatePlaybackServicePage();
        persistOpenTabs();
    }

    private void navigateFromAddress() {
        String input = address.getText() == null ? "" : address.getText().toString().trim();
        if (input.isEmpty()) {
            Toast.makeText(this, R.string.browser_invalid_url, Toast.LENGTH_SHORT).show();
            return;
        }
        ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(address.getWindowToken(), 0);
        address.clearFocus();
        navigate(input);
    }

    private void navigate(String input) {
        String value = input == null ? "" : input.trim();
        if (value.isEmpty()) return;
        String url;
        Uri parsed = Uri.parse(value);
        if (value.matches("(?i)^[a-z][a-z0-9+.-]*:.*") && parsed.getScheme() != null) {
            String scheme = parsed.getScheme().toLowerCase(Locale.ROOT);
            if ("http".equals(scheme) || "https".equals(scheme)) url = value;
            else if ("bitcoin".equals(scheme)) { routeUrl(parsed, true); return; }
            else if (scheme.equals("javascript") || scheme.equals("file") || scheme.equals("content")
                    || scheme.equals("data") || scheme.equals("intent") || scheme.equals("blob")) {
                Toast.makeText(this, R.string.browser_invalid_url, Toast.LENGTH_SHORT).show();
                return;
            } else { routeUrl(parsed, true); return; }
        } else if (value.contains(" ") || !value.contains(".")) {
            try { url = "https://www.google.com/search?q=" + URLEncoder.encode(value, StandardCharsets.UTF_8.name()); }
            catch (Exception ex) { Toast.makeText(this, R.string.browser_invalid_url, Toast.LENGTH_SHORT).show(); return; }
        } else {
            url = "https://" + value;
        }
        if (!isWebUrl(url)) {
            Toast.makeText(this, R.string.browser_invalid_url, Toast.LENGTH_SHORT).show();
            return;
        }
        WebView web = currentWebView();
        if (web == null) { createTab(url, true); return; }
        address.setText(url);
        web.loadUrl(url);
    }

    private void returnToMainWallet() {
        Intent intent = new Intent(this, wallet.main.MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        finish();
    }

    /** Persist every non-private tab so a normal app exit/relaunch restores the full tab strip. */
    private void persistOpenTabs() {
        if (privateMode || tabs.isEmpty()) return;
        JSONArray savedTabs = new JSONArray();
        int savedActive = Math.max(0, Math.min(activeTab, tabs.size() - 1));
        for (BrowserTab tab : tabs) {
            if (tab == null || tab.webView == null) continue;
            String url = tab.webView.getUrl();
            if (url == null || url.trim().isEmpty()) url = tab.url;
            if (url == null || url.trim().isEmpty()) url = "about:blank";
            JSONObject item = new JSONObject();
            try {
                item.put("url", url);
                String title = tab.title;
                item.put("title", title == null ? "" : title);
                savedTabs.put(item);
            } catch (org.json.JSONException ignored) { }
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString(KEY_OPEN_TABS, savedTabs.toString())
                .putInt(KEY_OPEN_ACTIVE_TAB, savedActive)
                .apply();
    }

    private static final String KEY_OPEN_ACTIVE_TAB = "open_tabs_active_index";

    /** Recreate saved tabs without replacing the saved list until every WebView is restored. */
    private boolean restoreOpenTabs() {
        if (privateMode) return false;
        android.content.SharedPreferences preferences = getSharedPreferences(PREFS, MODE_PRIVATE);
        String raw = preferences.getString(KEY_OPEN_TABS, "[]");
        JSONArray saved;
        try { saved = new JSONArray(raw); } catch (org.json.JSONException ex) { return false; }
        if (saved.length() == 0) return false;
        int active = preferences.getInt(KEY_OPEN_ACTIVE_TAB, 0);
        int restoredCount = 0;
        for (int i = 0; i < saved.length(); i++) {
            JSONObject item = saved.optJSONObject(i);
            if (item == null) continue;
            String url = item.optString("url", "about:blank");
            if (!"about:blank".equals(url) && !isWebUrl(url)) continue;
            createTab(null, false);
            BrowserTab tab = tabs.get(tabs.size() - 1);
            tab.url = url;
            String title = item.optString("title", "");
            tab.title = title.isEmpty() ? url : title;
            if (isWebUrl(url)) tab.webView.loadUrl(url);
            else tab.webView.loadUrl("about:blank");
            restoredCount++;
        }
        if (restoredCount == 0) return false;
        switchToTab(Math.max(0, Math.min(active, tabs.size() - 1)));
        return true;
    }

    private void loadHome() {
        String home = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_HOME_PAGE, "");
        if (home == null || home.trim().isEmpty()) {
            WebView web = currentWebView();
            if (web == null) {
                createTab(null, true);
                web = currentWebView();
            }
            if (web != null) {
                web.stopLoading();
                web.loadUrl("about:blank");
            }
            address.setText("");
            status.setText(R.string.browser_ready);
            return;
        }
        navigate(home.trim());
    }

    private void updateBrowserControls() {
        WebView web = currentWebView();

    }

    private void showBrowserMenu(View anchor) {
        PopupMenu menu = new PopupMenu(this, anchor);
        menu.inflate(R.menu.menu_browser_options);

        WebView web = currentWebView();
        menu.getMenu().findItem(R.id.browser_menu_back)
                .setEnabled(web != null && web.canGoBack());
        menu.getMenu().findItem(R.id.browser_menu_forward)
                .setEnabled(web != null && web.canGoForward());

        BrowserTab current = currentTab();
        boolean currentPageSaved = current != null && current.url != null
                && findByUrl(readArray(KEY_BOOKMARKS), current.url) >= 0;
        menu.getMenu().findItem(R.id.browser_menu_bookmark).setTitle(
                currentPageSaved ? R.string.browser_bookmark_remove_action : R.string.browser_bookmark);
        menu.getMenu().findItem(R.id.browser_menu_background).setTitle(
                backgroundSupport ? R.string.browser_background_stop : R.string.browser_background_play);

        menu.setOnMenuItemClickListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.browser_menu_back) {
                if (currentWebView() != null) currentWebView().goBack();
                return true;
            } else if (itemId == R.id.browser_menu_forward) {
                if (currentWebView() != null) currentWebView().goForward();
                return true;
            } else if (itemId == R.id.browser_menu_refresh) {
                if (currentWebView() != null) currentWebView().reload();
                return true;
            } else if (itemId == R.id.browser_menu_bookmark) {
                toggleBookmark();
                return true;
            } else if (itemId == R.id.browser_menu_history) {
                showStoredList(false);
                return true;
            } else if (itemId == R.id.browser_menu_find) {
                showFindDialog();
                return true;
            } else if (itemId == R.id.browser_menu_private) {
                togglePrivateMode();
                return true;
            } else if (itemId == R.id.browser_menu_background) {
                toggleBackgroundSupport();
                return true;
            } else if (itemId == R.id.browser_menu_downloads) {
                showDownloads();
                return true;
            } else if (itemId == R.id.browser_menu_clear_data) {
                confirmClearData();
                return true;
            } else if (itemId == R.id.browser_menu_bookmarks) {
                showStoredList(true);
                return true;
            } else if (itemId == R.id.browser_menu_settings) {
                startActivity(new Intent(this, BrowserSettingsActivity.class));
                return true;
            }
            return false;
        });
        try {
            java.lang.reflect.Field field = menu.getClass().getDeclaredField("mPopup");
            field.setAccessible(true);
            Object helper = field.get(menu);
            helper.getClass().getDeclaredMethod("setForceShowIcon", boolean.class).invoke(helper, true);
        } catch (Exception ignored) { }
        menu.show();
    }

    private void showTabs() {
        View content = getLayoutInflater().inflate(R.layout.dialog_browser_tabs, null);
        android.widget.LinearLayout list = content.findViewById(R.id.browserTabsList);
        for (int i = 0; i < tabs.size(); i++) {
            final int position = i;
            BrowserTab tab = tabs.get(i);
            View row = getLayoutInflater().inflate(R.layout.item_browser_tab, list, false);
            TextView title = row.findViewById(R.id.browserTabTitle);
            TextView host = row.findViewById(R.id.browserTabHost);
            android.widget.ImageView icon = row.findViewById(R.id.browserTabSiteIcon);
            android.widget.ImageButton close = row.findViewById(R.id.browserTabClose);
            String url = tab.url == null ? "" : tab.url;
            String label = tab.title == null || tab.title.trim().isEmpty()
                    ? (url.isEmpty() ? getString(R.string.browser_new_tab) : url) : tab.title.trim();
            title.setText(position == activeTab ? "● " + label : label);
            host.setText(url.isEmpty() ? getString(R.string.browser_blank_page_label) : url);
            bindTabSiteIcon(icon, url);

            row.setOnClickListener(v -> {
                if (position < 0 || position >= tabs.size()) return;
                switchToTab(position);
                AlertDialog dialog = tabsDialog;
                if (dialog != null) dialog.dismiss();
            });
            close.setContentDescription(getString(R.string.browser_close_tab));
            close.setOnClickListener(v -> {
                if (position < 0 || position >= tabs.size()) return;
                AlertDialog oldDialog = tabsDialog;
                closeTabAt(position);
                if (oldDialog != null) oldDialog.dismiss();
                // Closing a tab only updates the list; it does not select the tab first.
                showTabs();
            });
            list.addView(row);
        }

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(R.string.browser_tabs_title)
                .setView(content)
                .setNeutralButton(R.string.browser_new_tab, (d, which) -> createTab(null, true))
                .setNegativeButton(R.string.browser_close_tab, (d, which) -> closeCurrentTab())
                .setPositiveButton(android.R.string.cancel, null)
                .create();
        tabsDialog = dialog;
        dialog.setOnDismissListener(d -> {
            if (tabsDialog == dialog) tabsDialog = null;
        });
        dialog.show();
    }

    private AlertDialog tabsDialog;

    private void bindTabSiteIcon(android.widget.ImageView icon, String url) {
        String host = Uri.parse(url == null ? "" : url).getHost();
        if (host != null && !host.isEmpty()) {
            String encoded = getSharedPreferences(PREFS, MODE_PRIVATE)
                    .getString("favicon_" + host.toLowerCase(Locale.ROOT), null);
            if (encoded != null) {
                try {
                    byte[] bytes = Base64.decode(encoded, Base64.DEFAULT);
                    Bitmap bitmap = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                    if (bitmap != null) {
                        icon.setImageBitmap(bitmap);
                        icon.clearColorFilter();
                        return;
                    }
                } catch (IllegalArgumentException ignored) { }
            }
        }
        icon.setImageResource(R.drawable.ic_browser_site_24dp);
        icon.setColorFilter(resolveBrowserSecondaryColor());
    }

    private int resolveBrowserSecondaryColor() {
        android.util.TypedValue value = new android.util.TypedValue();
        getTheme().resolveAttribute(android.R.attr.textColorSecondary, value, true);
        return value.resourceId != 0 ? androidx.core.content.ContextCompat.getColor(this, value.resourceId) : value.data;
    }

    private void closeCurrentTab() { closeTabAt(activeTab); }

    private void closeTabAt(int index) {
        if (index < 0 || index >= tabs.size()) return;
        int previousActive = activeTab;
        boolean closingActive = index == previousActive;
        BrowserTab removed = tabs.remove(index);
        cancelSpeechRecognitionForWebView(removed.webView);
        if (backgroundSupport && removed == mediaOwnerTab) {
            try { removed.webView.evaluateJavascript("document.querySelectorAll('video,audio').forEach(function(m){try{m.pause();}catch(e){}});", null); }
            catch (RuntimeException ignored) { }
            mediaStateHandler.removeCallbacks(mediaStatePoll);
            mediaStateHandler.removeCallbacks(mediaProbeWatchdog);
            mediaProbeGeneration++;
            try {
                startService(new Intent(this, BrowserPlaybackService.class)
                        .setAction(BrowserPlaybackService.ACTION_STOP));
            } catch (RuntimeException ignored) { }
            backgroundSupport = false;
            backgroundPlaybackDesired = false;
            lastObservedMediaPlaying = false;
            mediaOwnerTab = null;
        }
        if (removed.webView.getParent() instanceof ViewGroup) ((ViewGroup) removed.webView.getParent()).removeView(removed.webView);
        removed.webView.stopLoading();
        if (removed.speechDocumentStartScript != null) {
            try { removed.speechDocumentStartScript.remove(); } catch (RuntimeException ignored) { }
            removed.speechDocumentStartScript = null;
        }
        removed.webView.setWebChromeClient(null);
        removed.webView.setWebViewClient(null);
        removed.webView.destroy();

        if (tabs.isEmpty()) {
            activeTab = -1;
            createTab(null, true);
            loadHome();
            return;
        }
        if (closingActive) {
            switchToTab(Math.min(index, tabs.size() - 1));
        } else if (index < previousActive) {
            // Removing a tab before the active tab shifts its index but should not switch pages.
            switchToTab(previousActive - 1);
        }
        // If an inactive tab after the current tab was closed, the current tab remains selected.
        persistOpenTabs();
    }

    private void toggleBookmark() {
        BrowserTab tab = currentTab();
        if (tab == null || !isWebUrl(tab.url)) {
            Toast.makeText(this, R.string.browser_invalid_url, Toast.LENGTH_SHORT).show();
            return;
        }
        JSONArray bookmarks = readArray(KEY_BOOKMARKS);
        int found = findByUrl(bookmarks, tab.url);
        if (found >= 0) {
            bookmarks.remove(found);
            writeArray(KEY_BOOKMARKS, bookmarks);
            Toast.makeText(this, R.string.browser_bookmark_removed, Toast.LENGTH_SHORT).show();
        } else {
            JSONObject item = new JSONObject();
            try { item.put("title", tab.title == null ? tab.url : tab.title); item.put("url", tab.url); item.put("time", System.currentTimeMillis()); bookmarks.put(item); }
            catch (JSONException ignored) { }
            writeArray(KEY_BOOKMARKS, bookmarks);
            Toast.makeText(this, R.string.browser_bookmark_saved, Toast.LENGTH_SHORT).show();
        }
    }

    private int findByUrl(JSONArray array, String url) {
        for (int i = 0; i < array.length(); i++) {
            JSONObject row = array.optJSONObject(i);
            if (row != null && url != null && url.equals(row.optString("url"))) return i;
        }
        return -1;
    }

    private void saveHistory(String title, String url) {
        JSONArray old = readArray(KEY_HISTORY);
        JSONArray next = new JSONArray();
        JSONObject entry = new JSONObject();
        try { entry.put("title", title == null ? url : title); entry.put("url", url); entry.put("time", System.currentTimeMillis()); next.put(entry); }
        catch (JSONException ignored) { }
        for (int i = 0; i < old.length() && next.length() < MAX_HISTORY; i++) {
            JSONObject row = old.optJSONObject(i);
            if (row != null && !url.equals(row.optString("url"))) next.put(row);
        }
        writeArray(KEY_HISTORY, next);
    }

    private JSONArray readArray(String key) {
        String raw = getSharedPreferences(PREFS, MODE_PRIVATE).getString(key, "[]");
        try { return new JSONArray(raw); } catch (JSONException ex) { return new JSONArray(); }
    }

    private void writeArray(String key, JSONArray value) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(key, value.toString()).apply();
    }

    private void showStoredList(boolean bookmarks) {
        Intent intent = new Intent(this, BrowserHistoryActivity.class);
        intent.putExtra(BrowserHistoryActivity.EXTRA_BOOKMARKS, bookmarks);
        startActivityForResult(intent, REQUEST_STORED_PAGE);
    }

    private void openStoredUrl(String rawUrl) {
        String url = rawUrl == null ? "" : rawUrl.trim();
        if (!isWebUrl(url)) {
            Toast.makeText(this, R.string.browser_invalid_url, Toast.LENGTH_SHORT).show();
            return;
        }
        WebView web = currentWebView();
        if (web == null) {
            createTab(url, true);
            return;
        }
        // Load into the active browser tab; do not launch an external browser or
        // create a second BrowserActivity for history/bookmark selections.
        address.setText(url);
        web.loadUrl(url);
        updateBrowserControls();
    }

    private void showFindDialog() {
        View content = getLayoutInflater().inflate(R.layout.dialog_browser_find, null);
        EditText query = content.findViewById(R.id.browserFindQuery);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(R.string.browser_find)
                .setView(content)
                .setNegativeButton(R.string.browser_find_previous, (d, w) -> {
                    WebView web = currentWebView();
                    if (web != null) web.findNext(false);
                })
                .setPositiveButton(R.string.browser_find_next, (d, w) -> {
                    WebView web = currentWebView();
                    String text = query.getText().toString();
                    if (web != null && !text.isEmpty()) {
                        web.findAllAsync(text);
                        web.setFindListener((activeMatchOrdinal, numberOfMatches, isDoneCounting) -> {
                            if (isDoneCounting && numberOfMatches == 0) Toast.makeText(this, R.string.browser_no_match, Toast.LENGTH_SHORT).show();
                        });
                    }
                }).create();
        dialog.setOnShowListener(d -> query.requestFocus());
        dialog.show();
    }

    private void shareCurrentPage() {
        BrowserTab tab = currentTab();
        if (tab == null || tab.url == null) return;
        Intent intent = new Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_TEXT, tab.url)
                .putExtra(Intent.EXTRA_SUBJECT, tab.title == null ? tab.url : tab.title);
        startActivity(Intent.createChooser(intent, getString(R.string.browser_share)));
    }

    private void togglePrivateMode() {
        if (!privateMode) {
            new AlertDialog.Builder(this)
                    .setTitle(R.string.browser_private_title)
                    .setMessage(R.string.browser_private_message)
                    .setNegativeButton(android.R.string.cancel, null)
                    .setPositiveButton(android.R.string.ok, (d, w) -> {
                        privateMode = true;
                        for (BrowserTab tab : tabs) CookieManager.getInstance().setAcceptThirdPartyCookies(tab.webView, false);
                        clearWebStorage(false);
                        updateBrowserControls();
                        Toast.makeText(this, R.string.browser_private_enabled, Toast.LENGTH_LONG).show();
                    }).show();
        } else {
            privateMode = false;
            for (BrowserTab tab : tabs) CookieManager.getInstance().setAcceptThirdPartyCookies(tab.webView, true);
            clearWebStorage(false);
            updateBrowserControls();
            Toast.makeText(this, R.string.browser_private_disabled, Toast.LENGTH_SHORT).show();
        }
    }

    private void confirmClearData() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.browser_clear_data_title)
                .setMessage(R.string.browser_clear_data_message)
                .setNegativeButton(android.R.string.cancel, null)
                .setPositiveButton(android.R.string.ok, (d, w) -> {
                    clearWebStorage(true);
                    Toast.makeText(this, R.string.browser_cleared, Toast.LENGTH_SHORT).show();
                }).show();
    }

    private void clearWebStorage(boolean clearHistory) {
        CookieManager cookies = CookieManager.getInstance();
        cookies.removeAllCookies(null);
        cookies.flush();
        for (BrowserTab tab : tabs) {
            tab.webView.clearCache(true);
            tab.webView.clearFormData();
            if (clearHistory) tab.webView.clearHistory();
        }
        if (clearHistory) {
            writeArray(KEY_HISTORY, new JSONArray());
            getSharedPreferences(PREFS_SITE_PERMISSIONS, MODE_PRIVATE).edit().clear().apply();
            GeolocationPermissions.getInstance().clearAll();
        }
        try { android.webkit.WebStorage.getInstance().deleteAllData(); }
        catch (RuntimeException ignored) { }
    }

    private void toggleBackgroundSupport() {
        if (backgroundSupport) {
            mediaStateHandler.removeCallbacks(mediaStatePoll);
            try {
                startService(new Intent(this, BrowserPlaybackService.class)
                        .setAction(BrowserPlaybackService.ACTION_STOP));
            } catch (RuntimeException ignored) { }
            setBackgroundMediaPlaybackPolicy(false);
            backgroundSupport = false;
            backgroundPlaybackDesired = false;
            lastObservedMediaPlaying = false;
            activityInBackground = false;
            updateBrowserControls();
            Toast.makeText(this, R.string.browser_background_stopped, Toast.LENGTH_SHORT).show();
            return;
        }
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this,
                Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_POST_NOTIFICATIONS);
            return;
        }
        // Background playback here is for media already playing in the current WebView.
        // Do not switch to a separate YouTube extractor/player path.
        WebView web = currentWebView();
        if (web == null) {
            startBackgroundService(false);
            return;
        }
        web.evaluateJavascript("(function(){var m=Array.prototype.slice.call(document.querySelectorAll('video,audio'));return m.some(function(x){return !x.paused && !x.ended;})?'1':'0';})()",
                value -> startBackgroundService("1".equals(value) || "\"1\"".equals(value)));
    }




    private void startBackgroundService(boolean mediaPlaying) {
        BrowserTab tab = currentTab();
        mediaOwnerTab = tab;
        Intent service = new Intent(this, BrowserPlaybackService.class)
                .setAction(BrowserPlaybackService.ACTION_START)
                .putExtra(BrowserPlaybackService.EXTRA_TITLE, tab == null ? getString(R.string.browser_title) : tab.title)
                .putExtra(BrowserPlaybackService.EXTRA_URL, tab == null ? "" : tab.url)
                .putExtra(BrowserPlaybackService.EXTRA_PLAYING, mediaPlaying);
        try {
            ContextCompat.startForegroundService(this, service);
            backgroundSupport = true;
            backgroundPlaybackDesired = mediaPlaying;
            setBackgroundMediaPlaybackPolicy(true);
            lastObservedMediaPlaying = mediaPlaying;
            updateBrowserControls();
            mediaStateHandler.removeCallbacks(mediaStatePoll);
            mediaStateHandler.postDelayed(mediaStatePoll, 1000L);
            Toast.makeText(this, R.string.browser_background_started, Toast.LENGTH_LONG).show();
        } catch (RuntimeException ex) {
            backgroundSupport = false;
            Toast.makeText(this, R.string.browser_download_failed, Toast.LENGTH_LONG).show();
            updateBrowserControls();
        }
    }

    private void publishMediaState(boolean isPlaying) {
        // While visible, follow the user's actual play/pause actions so leaving the app
        // does not unexpectedly restart media that was deliberately paused.
        if (!activityInBackground) backgroundPlaybackDesired = isPlaying;
        if (lastObservedMediaPlaying == isPlaying) return;
        lastObservedMediaPlaying = isPlaying;
        Intent state = new Intent(this, BrowserPlaybackService.class)
                .setAction(BrowserPlaybackService.ACTION_STATE)
                .putExtra(BrowserPlaybackService.EXTRA_PLAYING, isPlaying);
        try { startService(state); } catch (RuntimeException ignored) { }
    }

    private void updatePlaybackServicePage() {
        BrowserTab tab = mediaOwnerTab == null ? currentTab() : mediaOwnerTab;
        if (tab == null || !backgroundSupport) return;
        Intent service = new Intent(this, BrowserPlaybackService.class)
                .setAction(BrowserPlaybackService.ACTION_PAGE)
                .putExtra(BrowserPlaybackService.EXTRA_TITLE, tab.title)
                .putExtra(BrowserPlaybackService.EXTRA_URL, tab.url);
        try { startService(service); } catch (RuntimeException ignored) { }
    }

    private void showDownloads() {
        startActivity(new Intent(this, BrowserDownloadsActivity.class));
    }

    private void downloadFile(WebView webView, String url, String userAgent,
            String contentDisposition, String mimeType) {
        if (url == null || (!url.startsWith("https://") && !url.startsWith("http://"))) {
            Toast.makeText(this, R.string.browser_download_failed, Toast.LENGTH_LONG).show();
            return;
        }
        try {
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            request.setMimeType(mimeType);
            String cookies = CookieManager.getInstance().getCookie(url);
            if (cookies != null) request.addRequestHeader("Cookie", cookies);
            if (userAgent != null) request.addRequestHeader("User-Agent", userAgent);
            request.setTitle(URLUtil.guessFileName(url, contentDisposition, mimeType));
            request.setDescription(url);
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                    URLUtil.guessFileName(url, contentDisposition, mimeType));
            DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            if (manager == null) throw new LocalizedErrors.IllegalStateException(R.string.browser_download_service_unavailable);
            manager.enqueue(request);
            Toast.makeText(this, R.string.browser_download_started, Toast.LENGTH_SHORT).show();
        } catch (RuntimeException ex) {
            Toast.makeText(this, R.string.browser_download_failed, Toast.LENGTH_LONG).show();
        }
    }

    private void installWebPermissionStatusCompatibility(WebView webView) {
        String currentUrl = webView.getUrl();
        if (currentUrl == null || !"https".equalsIgnoreCase(Uri.parse(currentUrl).getScheme())) return;

        boolean microphoneGranted = ContextCompat.checkSelfPermission(this,
                Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        boolean cameraGranted = ContextCompat.checkSelfPermission(this,
                Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
        boolean locationGranted = ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        String script = "(function(){try{"
                + "var states={microphone:" + (microphoneGranted ? "'granted'" : "'prompt'")
                + ",camera:" + (cameraGranted ? "'granted'" : "'prompt'")
                + ",geolocation:" + (locationGranted ? "'granted'" : "'prompt'") + "};"
                + "var nav=window.navigator;if(!nav)return;"
                + "var permissions=nav.permissions;"
                + "if(!permissions){permissions={};try{Object.defineProperty(nav,'permissions',{configurable:true,value:permissions});}catch(e){return;}}"
                + "var original=typeof permissions.query==='function'?permissions.query.bind(permissions):null;"
                + "permissions.query=function(descriptor){var name=descriptor&&descriptor.name;"
                + "if(Object.prototype.hasOwnProperty.call(states,name)){var status={state:states[name],onchange:null,addEventListener:function(){},removeEventListener:function(){},dispatchEvent:function(){return true;}};return Promise.resolve(status);}"
                + "if(original)return original(descriptor);return Promise.reject(new TypeError('Unsupported permission'));};"
                + "}catch(e){}})();";
        try { webView.evaluateJavascript(script, null); } catch (RuntimeException ignored) { }
    }

    private boolean isYouTubeSpeechUrl(String rawUrl) {
        String origin = secureWebsiteOrigin(rawUrl);
        if (origin == null) return false;
        String host = Uri.parse(origin).getHost();
        return host != null && (host.equalsIgnoreCase("youtube.com")
                || host.toLowerCase(Locale.ROOT).endsWith(".youtube.com"));
    }

    private void handleNativeSpeechMessage(WebView owner, String expectedToken,
            WebMessageCompat message, Uri sourceOrigin, boolean isMainFrame) {
        if (!isMainFrame || owner == null || message == null || sourceOrigin == null
                || isFinishing() || isDestroyed()) return;

        String messageOrigin = secureWebsiteOrigin(sourceOrigin.toString());
        String pageOrigin = secureWebsiteOrigin(owner.getUrl());
        if (messageOrigin == null || !messageOrigin.equals(pageOrigin)
                || !isYouTubeSpeechUrl(messageOrigin)) return;

        final JSONObject command;
        try {
            String data = message.getData();
            if (data == null || data.length() > 4096) return;
            command = new JSONObject(data);
        } catch (JSONException ignored) {
            return;
        }

        if (!expectedToken.equals(command.optString("token"))) return;
        String sessionId = command.optString("sessionId", "");
        if (sessionId.trim().isEmpty() || sessionId.length() > 80) return;
        String action = command.optString("action", "");

        if ("start".equals(action)) {
            String language = command.optString("language", Locale.getDefault().toLanguageTag());
            boolean continuous = command.optBoolean("continuous", false);
            boolean interimResults = command.optBoolean("interimResults", false);
            int maxAlternatives = Math.max(1, Math.min(5, command.optInt("maxAlternatives", 1)));
            runOnUiThread(() -> startNativeSpeechRecognition(owner, expectedToken, sessionId,
                    language, continuous, interimResults, maxAlternatives));
        } else if ("stop".equals(action) || "abort".equals(action)) {
            boolean abort = "abort".equals(action);
            runOnUiThread(() -> stopNativeSpeechRecognition(owner, expectedToken, sessionId, abort));
        }
    }

    public final class BrowserSpeechBridge {
        private final WebView owner;
        private final String token;

        BrowserSpeechBridge(WebView owner, String token) {
            this.owner = owner;
            this.token = token;
        }

        @android.webkit.JavascriptInterface
        public void start(String suppliedToken, String sessionId, String language,
                boolean continuous, boolean interimResults, int maxAlternatives) {
            if (!token.equals(suppliedToken) || sessionId == null || sessionId.trim().isEmpty()) return;
            runOnUiThread(() -> startNativeSpeechRecognition(owner, token, sessionId,
                    language, continuous, interimResults, maxAlternatives));
        }

        @android.webkit.JavascriptInterface
        public void stop(String suppliedToken, String sessionId, boolean abort) {
            if (!token.equals(suppliedToken) || sessionId == null) return;
            runOnUiThread(() -> stopNativeSpeechRecognition(owner, token, sessionId, abort));
        }
    }

    private void installSpeechRecognitionBridge(WebView webView, String token) {
        if (webView == null || token == null || token.isEmpty()
                || !isYouTubeSpeechUrl(webView.getUrl())) return;
        String script = buildSpeechRecognitionBridgeScript(token);
        try { webView.evaluateJavascript(script, null); } catch (RuntimeException ignored) { }
    }

    private String buildSpeechRecognitionBridgeScript(String token) {
        return "(function(){"
                + "if(window.top!==window||window.__browserNativeSpeechInstalled)return;"
                + "var token=" + JSONObject.quote(token) + ";"
                + "var instances=Object.create(null),nextId=0;"
                + "function Recognition(){this.lang=(navigator.language||'en-US');this.continuous=false;"
                + "this.interimResults=false;this.maxAlternatives=1;this.onaudiostart=null;this.onsoundstart=null;"
                + "this.onspeechstart=null;this.onspeechend=null;this.onsoundend=null;this.onaudioend=null;"
                + "this.onresult=null;this.onnomatch=null;this.onerror=null;this.onstart=null;this.onend=null;"
                + "this._id=String(++nextId);this._active=false;this._listeners=Object.create(null);instances[this._id]=this;}"
                + "Recognition.prototype.addEventListener=function(type,fn){if(typeof fn!=='function')return;"
                + "(this._listeners[type]||(this._listeners[type]=[])).push(fn);};"
                + "Recognition.prototype.removeEventListener=function(type,fn){var a=this._listeners[type]||[];"
                + "this._listeners[type]=a.filter(function(x){return x!==fn;});};"
                + "Recognition.prototype.dispatchEvent=function(event){var a=(this._listeners[event.type]||[]).slice();"
                + "for(var i=0;i<a.length;i++){try{a[i].call(this,event);}catch(e){}}"
                + "var h=this['on'+event.type];if(typeof h==='function'){try{h.call(this,event);}catch(e){}}return true;};"
                + "Recognition.prototype.start=function(){if(this._active)throw new Error('Recognition has already started');"
                + "this._active=true;var bridge=window.BrowserSpeechBridge;"
                + "var command={action:'start',token:token,sessionId:this._id,"
                + "language:this.lang||navigator.language||'vi-VN',continuous:!!this.continuous,"
                + "interimResults:!!this.interimResults,maxAlternatives:Math.max(1,Math.min(5,this.maxAlternatives||1))};"
                + "if(bridge&&typeof bridge.postMessage==='function'){bridge.postMessage(JSON.stringify(command));return;}"
                + "if(bridge&&typeof bridge.start==='function'){bridge.start(token,this._id,command.language,"
                + "command.continuous,command.interimResults,command.maxAlternatives);return;}"
                + "this._active=false;var e=new Event('error');e.error='service-not-allowed';"
                + "this.dispatchEvent(e);this.dispatchEvent(new Event('end'));};"
                + "Recognition.prototype.stop=function(){var bridge=window.BrowserSpeechBridge;if(!this._active||!bridge)return;"
                + "if(typeof bridge.postMessage==='function')bridge.postMessage(JSON.stringify({action:'stop',token:token,sessionId:this._id}));"
                + "else if(typeof bridge.stop==='function')bridge.stop(token,this._id,false);};"
                + "Recognition.prototype.abort=function(){var bridge=window.BrowserSpeechBridge;if(!this._active||!bridge)return;"
                + "if(typeof bridge.postMessage==='function')bridge.postMessage(JSON.stringify({action:'abort',token:token,sessionId:this._id}));"
                + "else if(typeof bridge.stop==='function')bridge.stop(token,this._id,true);};"
                + "window.__browserSpeechDispatch=function(id,type,data){var r=instances[id];if(!r)return;data=data||{};"
                + "if(type==='result'){if(data.isFinal===false&&!r.interimResults)return;var alts=(data.alternatives||[]).map(function(a){"
                + "return {transcript:String(a.transcript||''),confidence:typeof a.confidence==='number'?a.confidence:0};});"
                + "var result=alts;result.isFinal=!!data.isFinal;result.item=function(i){return result[i]||null;};"
                + "var results=[result];results.item=function(i){return results[i]||null;};"
                + "var ev=new Event('result');ev.results=results;ev.resultIndex=0;ev.emma=null;ev.interpretation=null;r.dispatchEvent(ev);return;}"
                + "var ev=new Event(type);Object.keys(data).forEach(function(k){try{ev[k]=data[k];}catch(e){}});"
                + "r.dispatchEvent(ev);if(type==='end'){r._active=false;}};"
                + "window.SpeechRecognition=window.webkitSpeechRecognition=Recognition;"
                + "window.__browserNativeSpeechInstalled=true;"
                + "})();";
    }

    private String secureWebsiteOrigin(String rawUrl) {
        if (rawUrl == null || rawUrl.trim().isEmpty()) return null;
        try {
            Uri uri = Uri.parse(rawUrl);
            if (!"https".equalsIgnoreCase(uri.getScheme()) || uri.getHost() == null
                    || uri.getHost().trim().isEmpty()) return null;
            StringBuilder origin = new StringBuilder("https://")
                    .append(uri.getHost().toLowerCase(Locale.ROOT));
            if (uri.getPort() != -1) origin.append(':').append(uri.getPort());
            return origin.toString();
        } catch (RuntimeException ignored) {
            return null;
        }
    }

    private void startNativeSpeechRecognition(WebView owner, String token, String sessionId,
            String language, boolean continuous, boolean interimResults, int maxAlternatives) {
        if (owner == null || isFinishing() || isDestroyed()) return;
        String origin = secureWebsiteOrigin(owner.getUrl());
        if (origin == null || !areWebsitePermissionsAllowed(origin,
                new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE})
                || ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            dispatchSpeechFailure(owner, sessionId, "not-allowed",
                    "Microphone permission has not been granted to this website.");
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            dispatchSpeechFailure(owner, sessionId, "service-not-allowed",
                    "No Android speech recognition service is available.");
            return;
        }
        cancelSpeechRecognition(false);
        final SpeechRecognizer recognizer;
        try {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        } catch (RuntimeException ex) {
            dispatchSpeechFailure(owner, sessionId, "service-not-allowed",
                    "Unable to start the Android speech recognition service.");
            return;
        }
        speechRecognizer = recognizer;
        speechOwnerWebView = owner;
        speechSessionId = sessionId;
        speechSessionToken = token;
        speechRetryCount = 0;
        speechStopRequested = false;
        speechStartEventSent = false;
        recognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) {
                if (!isCurrentSpeechSession(owner, sessionId, recognizer)) return;
                if (!speechStartEventSent) {
                    speechStartEventSent = true;
                    dispatchSpeechEvent(owner, sessionId, "start", null);
                }
                dispatchSpeechEvent(owner, sessionId, "audiostart", null);
                dispatchSpeechEvent(owner, sessionId, "soundstart", null);
            }
            @Override public void onBeginningOfSpeech() {
                if (isCurrentSpeechSession(owner, sessionId, recognizer)) {
                    dispatchSpeechEvent(owner, sessionId, "speechstart", null);
                }
            }
            @Override public void onRmsChanged(float rmsdB) { }
            @Override public void onBufferReceived(byte[] buffer) { }
            @Override public void onEndOfSpeech() {
                if (!isCurrentSpeechSession(owner, sessionId, recognizer)) return;
                // Speech may have paused while the recognizer is still producing a
                // result or is about to be restarted after a no-speech timeout.
                // Do not signal audioend here: Web Speech clients treat it as the
                // end of the capture session and close their listening UI.
                dispatchSpeechEvent(owner, sessionId, "speechend", null);
            }
            @Override public void onError(int error) {
                if (!isCurrentSpeechSession(owner, sessionId, recognizer)) return;
                if (!speechStopRequested && scheduleSpeechRetry(owner, sessionId, recognizer, error)) {
                    return;
                }
                dispatchSpeechError(owner, sessionId, mapSpeechRecognizerError(error),
                        "Android speech recognition failed (" + error + ").");
                finishSpeechRecognition(owner, sessionId, recognizer, true);
            }
            @Override public void onResults(Bundle results) {
                if (!isCurrentSpeechSession(owner, sessionId, recognizer)) return;
                JSONObject payload = speechResultsPayload(results, true);
                if (payload == null || payload.optJSONArray("alternatives") == null
                        || payload.optJSONArray("alternatives").length() == 0) {
                    if (!speechStopRequested && scheduleSpeechRetry(owner, sessionId, recognizer,
                            SpeechRecognizer.ERROR_NO_MATCH)) return;
                    dispatchSpeechError(owner, sessionId, "no-speech", "No speech was recognized.");
                } else {
                    dispatchSpeechEvent(owner, sessionId, "result", payload);
                }
                finishSpeechRecognition(owner, sessionId, recognizer, true);
            }
            @Override public void onPartialResults(Bundle partialResults) {
                if (!isCurrentSpeechSession(owner, sessionId, recognizer)) return;
                JSONObject payload = speechResultsPayload(partialResults, false);
                if (payload != null && payload.optJSONArray("alternatives") != null
                        && payload.optJSONArray("alternatives").length() > 0) {
                    dispatchSpeechEvent(owner, sessionId, "result", payload);
                }
            }
            @Override public void onEvent(int eventType, Bundle params) { }
        });

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        String requestedLanguage = language == null ? "" : language.trim();
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE,
                requestedLanguage.isEmpty() ? Locale.getDefault().toLanguageTag() : requestedLanguage);
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, Math.max(1, Math.min(maxAlternatives, 5)));
        intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());

        // Keep the recognizer open long enough for the user to begin speaking.
        // Some Android recognition services otherwise return ERROR_SPEECH_TIMEOUT
        // almost immediately after the listening UI appears.
        intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 15000L);
        intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 4000L);
        intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 6000L);
        if (Build.VERSION.SDK_INT >= 23) intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false);
        speechRecognitionIntent = intent;
        try {
            recognizer.startListening(intent);
        } catch (RuntimeException ex) {
            dispatchSpeechError(owner, sessionId, "service-not-allowed",
                    "The Android speech recognition service could not start.");
            finishSpeechRecognition(owner, sessionId, recognizer, true);
        }
    }

    private boolean scheduleSpeechRetry(WebView owner, String sessionId,
            SpeechRecognizer recognizer, int error) {
        if (error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                && error != SpeechRecognizer.ERROR_NO_MATCH) return false;
        if (!isCurrentSpeechSession(owner, sessionId, recognizer)
                || speechStopRequested || speechRecognitionIntent == null
                || speechRetryCount >= MAX_SPEECH_RETRIES) return false;

        speechRetryCount++;
        if (speechRetryRunnable != null) {
            mediaStateHandler.removeCallbacks(speechRetryRunnable);
        }
        // Keep the Web Speech capture session open while Android is restarted.
        // Sending soundend/audioend here makes YouTube close its listening overlay
        // before the native retry can receive the user's next words.
        speechRetryRunnable = () -> {
            speechRetryRunnable = null;
            if (!isCurrentSpeechSession(owner, sessionId, recognizer) || speechStopRequested) return;
            try {
                recognizer.startListening(speechRecognitionIntent);
            } catch (RuntimeException ex) {
                dispatchSpeechError(owner, sessionId, "service-not-allowed",
                        "The Android speech recognition service could not restart.");
                finishSpeechRecognition(owner, sessionId, recognizer, true);
            }
        };
        mediaStateHandler.postDelayed(speechRetryRunnable, SPEECH_RETRY_DELAY_MS);
        return true;
    }

    private JSONObject speechResultsPayload(Bundle bundle, boolean isFinal) {
        if (bundle == null) return null;
        ArrayList<String> matches = bundle.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (matches == null || matches.isEmpty()) return null;
        float[] confidence = bundle.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES);
        JSONArray alternatives = new JSONArray();
        for (int i = 0; i < matches.size(); i++) {
            JSONObject item = new JSONObject();
            try {
                item.put("transcript", matches.get(i) == null ? "" : matches.get(i));
                item.put("confidence", confidence != null && i < confidence.length
                        ? confidence[i] : 0.0);
                alternatives.put(item);
            } catch (JSONException ignored) { }
        }
        JSONObject payload = new JSONObject();
        try {
            payload.put("alternatives", alternatives);
            payload.put("isFinal", isFinal);
            return payload;
        } catch (JSONException ignored) {
            return null;
        }
    }

    private String mapSpeechRecognizerError(int error) {
        switch (error) {
            case SpeechRecognizer.ERROR_AUDIO: return "audio-capture";
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: return "not-allowed";
            case SpeechRecognizer.ERROR_NETWORK:
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT: return "network";
            case SpeechRecognizer.ERROR_NO_MATCH:
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT: return "no-speech";
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: return "service-not-allowed";
            case SpeechRecognizer.ERROR_SERVER:
            case SpeechRecognizer.ERROR_SERVER_DISCONNECTED: return "network";
            case SpeechRecognizer.ERROR_CLIENT: return "aborted";
            default: return "unknown";
        }
    }

    private boolean isCurrentSpeechSession(WebView owner, String sessionId,
            SpeechRecognizer recognizer) {
        return speechOwnerWebView == owner && speechRecognizer == recognizer
                && sessionId != null && sessionId.equals(speechSessionId);
    }

    private void dispatchSpeechError(WebView owner, String sessionId, String error, String message) {
        JSONObject payload = new JSONObject();
        try {
            payload.put("error", error);
            payload.put("message", message == null ? "" : message);
        } catch (JSONException ignored) { }
        dispatchSpeechEvent(owner, sessionId, "error", payload);
    }

    private void dispatchSpeechFailure(WebView owner, String sessionId, String error, String message) {
        dispatchSpeechError(owner, sessionId, error, message);
        dispatchSpeechEvent(owner, sessionId, "end", null);
    }

    private void dispatchSpeechEvent(WebView owner, String sessionId, String eventName,
            JSONObject payload) {
        if (owner == null || sessionId == null || isFinishing() || isDestroyed()) return;
        String script = "if(window.__browserSpeechDispatch)window.__browserSpeechDispatch("
                + JSONObject.quote(sessionId) + "," + JSONObject.quote(eventName) + ","
                + (payload == null ? "{}" : payload.toString()) + ");";
        try { owner.evaluateJavascript(script, null); } catch (RuntimeException ignored) { }
    }

    private void finishSpeechRecognition(WebView owner, String sessionId,
            SpeechRecognizer recognizer, boolean sendEnd) {
        if (!isCurrentSpeechSession(owner, sessionId, recognizer)) return;
        if (speechRetryRunnable != null) {
            mediaStateHandler.removeCallbacks(speechRetryRunnable);
            speechRetryRunnable = null;
        }
        speechRecognizer = null;
        speechOwnerWebView = null;
        speechSessionId = null;
        speechSessionToken = null;
        speechRecognitionIntent = null;
        speechStopRequested = false;
        speechStartEventSent = false;
        if (sendEnd) {
            dispatchSpeechEvent(owner, sessionId, "soundend", null);
            dispatchSpeechEvent(owner, sessionId, "audioend", null);
            dispatchSpeechEvent(owner, sessionId, "end", null);
        }
        try { recognizer.destroy(); } catch (RuntimeException ignored) { }
    }

    private void stopNativeSpeechRecognition(WebView owner, String token,
            String sessionId, boolean abort) {
        if (owner != speechOwnerWebView || !token.equals(speechSessionToken)
                || !sessionId.equals(speechSessionId) || speechRecognizer == null) return;
        SpeechRecognizer recognizer = speechRecognizer;
        if (abort) {
            if (speechRetryRunnable != null) {
                mediaStateHandler.removeCallbacks(speechRetryRunnable);
                speechRetryRunnable = null;
            }
            speechRecognizer = null;
            speechOwnerWebView = null;
            speechSessionId = null;
            speechSessionToken = null;
            speechRecognitionIntent = null;
            speechStopRequested = false;
            speechStartEventSent = false;
            try { recognizer.cancel(); } catch (RuntimeException ignored) { }
            try { recognizer.destroy(); } catch (RuntimeException ignored) { }
            dispatchSpeechEvent(owner, sessionId, "end", null);
        } else {
            speechStopRequested = true;
            if (speechRetryRunnable != null) {
                mediaStateHandler.removeCallbacks(speechRetryRunnable);
                speechRetryRunnable = null;
                finishSpeechRecognition(owner, sessionId, recognizer, true);
                return;
            }
            try { recognizer.stopListening(); } catch (RuntimeException ex) {
                finishSpeechRecognition(owner, sessionId, recognizer, true);
            }
        }
    }

    private void cancelSpeechRecognition(boolean sendEnd) {
        SpeechRecognizer recognizer = speechRecognizer;
        WebView owner = speechOwnerWebView;
        String sessionId = speechSessionId;
        if (speechRetryRunnable != null) {
            mediaStateHandler.removeCallbacks(speechRetryRunnable);
            speechRetryRunnable = null;
        }
        speechRecognizer = null;
        speechOwnerWebView = null;
        speechSessionId = null;
        speechSessionToken = null;
        speechRecognitionIntent = null;
        speechStopRequested = false;
        speechStartEventSent = false;
        if (recognizer != null) {
            try { recognizer.cancel(); } catch (RuntimeException ignored) { }
            try { recognizer.destroy(); } catch (RuntimeException ignored) { }
        }
        if (sendEnd && owner != null && sessionId != null) {
            dispatchSpeechEvent(owner, sessionId, "end", null);
        }
    }

    private void cancelSpeechRecognitionForWebView(WebView webView) {
        if (speechOwnerWebView == webView) cancelSpeechRecognition(false);
    }

    private void requestWebPermission(PermissionRequest request) {
        if (request == null || isFinishing() || isDestroyed()) {
            if (request != null) request.deny();
            return;
        }

        Uri requestOrigin = request.getOrigin();
        if (requestOrigin == null || !"https".equalsIgnoreCase(requestOrigin.getScheme())
                || requestOrigin.getHost() == null || requestOrigin.getHost().trim().isEmpty()) {
            request.deny();
            return;
        }

        String[] requestedResources = request.getResources();
        if (requestedResources == null || requestedResources.length == 0) {
            request.deny();
            return;
        }
        ArrayList<String> grantableResources = new ArrayList<>();
        ArrayList<String> androidPermissions = new ArrayList<>();
        boolean unsupportedResourceRequested = false;
        for (String resource : requestedResources) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) {
                grantableResources.add(resource);
                if (!androidPermissions.contains(Manifest.permission.RECORD_AUDIO)) {
                    androidPermissions.add(Manifest.permission.RECORD_AUDIO);
                }
            } else if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)) {
                grantableResources.add(resource);
                if (!androidPermissions.contains(Manifest.permission.CAMERA)) {
                    androidPermissions.add(Manifest.permission.CAMERA);
                }
            } else {
                // Never grant an unknown resource, even when it accompanies a known one.
                unsupportedResourceRequested = true;
            }
        }
        if (unsupportedResourceRequested || grantableResources.isEmpty()) {
            request.deny();
            return;
        }
        if (pendingPermissionRequest != null) {
            request.deny();
            return;
        }

        String origin = secureWebsiteOrigin(requestOrigin.toString());
        if (origin == null) { request.deny(); return; }
        String[] resources = grantableResources.toArray(new String[0]);
        boolean allAndroidPermissionsGranted = true;
        for (String permission : androidPermissions) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                allAndroidPermissionsGranted = false;
                break;
            }
        }

        if (allAndroidPermissionsGranted && areWebsitePermissionsAllowed(origin, resources)) {
            request.grant(resources);
            return;
        }

        pendingPermissionRequest = request;
        pendingWebResources = resources;
        pendingWebPermissionOrigin = origin;
        if (!allAndroidPermissionsGranted) {
            requestPermissions(androidPermissions.toArray(new String[0]), REQUEST_WEB_PERMISSION);
        } else {
            showWebsitePermissionConfirmation();
        }
    }

    private boolean areWebsitePermissionsAllowed(String origin, String[] resources) {
        if (privateMode) return false;
        android.content.SharedPreferences preferences = getSharedPreferences(
                PREFS_SITE_PERMISSIONS, MODE_PRIVATE);
        for (String resource : resources) {
            if (!preferences.getBoolean(websitePermissionKey(origin, resource), false)) return false;
        }
        return true;
    }

    private String websitePermissionKey(String origin, String resource) {
        return "allow_" + Uri.encode(origin + "|" + resource);
    }

    private void showWebsitePermissionConfirmation() {
        if (pendingPermissionRequest == null || pendingWebResources == null
                || pendingWebPermissionOrigin == null || isFinishing() || isDestroyed()) {
            denyPendingWebPermission();
            return;
        }

        StringBuilder requestedFeatures = new StringBuilder();
        for (String resource : pendingWebResources) {
            if (requestedFeatures.length() > 0) requestedFeatures.append(", ");
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) {
                requestedFeatures.append(getString(R.string.browser_permission_microphone));
            } else if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)) {
                requestedFeatures.append(getString(R.string.browser_permission_camera));
            }
        }
        final String origin = pendingWebPermissionOrigin;
        final PermissionRequest request = pendingPermissionRequest;
        final String[] resources = pendingWebResources.clone();

        pendingWebPermissionDialog = new AlertDialog.Builder(this)
                .setTitle(R.string.browser_permission_title)
                .setMessage(getString(R.string.browser_permission_site_message, origin, requestedFeatures.toString()))
                .setNegativeButton(android.R.string.cancel, (dialog, which) -> denyPendingWebPermission())
                .setPositiveButton(android.R.string.ok, (dialog, which) -> {
                    if (pendingPermissionRequest != request) return;
                    if (!privateMode) {
                        android.content.SharedPreferences.Editor editor = getSharedPreferences(
                                PREFS_SITE_PERMISSIONS, MODE_PRIVATE).edit();
                        for (String resource : resources) {
                            editor.putBoolean(websitePermissionKey(origin, resource), true);
                        }
                        editor.apply();
                    }
                    clearPendingWebPermission(false);
                    try { request.grant(resources); } catch (RuntimeException ignored) { }
                })
                .create();
        pendingWebPermissionDialog.setOnCancelListener(dialog -> denyPendingWebPermission());
        pendingWebPermissionDialog.show();
    }

    private void denyPendingWebPermission() {
        PermissionRequest request = pendingPermissionRequest;
        clearPendingWebPermission(true);
        if (request != null) {
            try { request.deny(); } catch (RuntimeException ignored) { }
        }
    }

    private void clearPendingWebPermission(boolean dismissDialog) {
        if (pendingWebPermissionDialog != null) {
            AlertDialog dialog = pendingWebPermissionDialog;
            pendingWebPermissionDialog = null;
            if (dismissDialog && dialog.isShowing()) dialog.dismiss();
        }
        pendingPermissionRequest = null;
        pendingWebResources = null;
        pendingWebPermissionOrigin = null;
    }

    private void cancelPendingWebPermission(PermissionRequest request) {
        if (pendingPermissionRequest == request) clearPendingWebPermission(true);
    }

    private void requestGeolocation(String origin, GeolocationPermissions.Callback callback) {
        new AlertDialog.Builder(this)
                .setTitle(R.string.browser_permission_title)
                .setMessage(getString(R.string.browser_geolocation_permission_message, origin))
                .setNegativeButton(android.R.string.cancel, (d, w) -> callback.invoke(origin, false, false))
                .setPositiveButton(android.R.string.ok, (d, w) -> {
                    boolean fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                            == PackageManager.PERMISSION_GRANTED;
                    boolean coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                            == PackageManager.PERMISSION_GRANTED;
                    if (fine || coarse) {
                        callback.invoke(origin, true, true);
                    } else {
                        pendingGeoCallback = callback;
                        pendingGeoOrigin = origin;
                        requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION,
                                Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_GEO_PERMISSION);
                    }
                }).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_WEB_PERMISSION) {
            boolean granted = grantResults.length > 0;
            for (int result : grantResults) granted &= result == PackageManager.PERMISSION_GRANTED;
            if (pendingPermissionRequest != null) {
                if (granted) {
                    if (areWebsitePermissionsAllowed(pendingWebPermissionOrigin, pendingWebResources)) {
                        PermissionRequest request = pendingPermissionRequest;
                        String[] resources = pendingWebResources.clone();
                        clearPendingWebPermission(false);
                        try { request.grant(resources); } catch (RuntimeException ignored) { }
                    } else {
                        showWebsitePermissionConfirmation();
                    }
                } else {
                    denyPendingWebPermission();
                }
            }
        } else if (requestCode == REQUEST_GEO_PERMISSION) {
            boolean granted = false;
            for (int result : grantResults) granted |= result == PackageManager.PERMISSION_GRANTED;
            if (pendingGeoCallback != null) pendingGeoCallback.invoke(pendingGeoOrigin, granted, granted);
            pendingGeoCallback = null;
            pendingGeoOrigin = null;
        } else if (requestCode == REQUEST_POST_NOTIFICATIONS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) toggleBackgroundSupport();
            else Toast.makeText(this, R.string.browser_background_note, Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_STORED_PAGE) {
            if (resultCode == RESULT_OK && data != null) {
                openStoredUrl(data.getStringExtra(EXTRA_URL));
            }
            return;
        }
        if (requestCode == REQUEST_FILE && fileChooserCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    ClipData clip = data.getClipData();
                    results = new Uri[clip.getItemCount()];
                    for (int i = 0; i < clip.getItemCount(); i++) results[i] = clip.getItemAt(i).getUri();
                } else if (data.getData() != null) results = new Uri[]{data.getData()};
            }
            fileChooserCallback.onReceiveValue(results);
            fileChooserCallback = null;
        }
    }

    private void enterFullscreen(View view, WebChromeClient.CustomViewCallback callback) {
        if (fullscreenView != null) {
            callback.onCustomViewHidden();
            return;
        }
        fullscreenView = view;
        fullscreenCallback = callback;
        savedSystemUiVisibility = getWindow().getDecorView().getSystemUiVisibility();
        browserRoot.setVisibility(View.GONE);
        addContentView(view, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    private void exitFullscreen() {
        if (fullscreenView == null) return;
        try {
            ViewGroup parent = (ViewGroup) fullscreenView.getParent();
            if (parent != null) parent.removeView(fullscreenView);
        } catch (RuntimeException ignored) { }
        fullscreenView = null;
        browserRoot.setVisibility(View.VISIBLE);
        getWindow().getDecorView().setSystemUiVisibility(savedSystemUiVisibility);
        if (fullscreenCallback != null) {
            fullscreenCallback.onCustomViewHidden();
            fullscreenCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (fullscreenView != null) {
            exitFullscreen();
            return;
        }
        WebView web = currentWebView();
        if (web != null && web.canGoBack()) {
            web.goBack();
        } else if (tabs.size() > 1) {
            closeCurrentTab();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (backgroundSupport) {
            activityInBackground = true;
            reinforceBackgroundPlayback();
        }
    }

    @Override
    protected void onPause() {
        cancelSpeechRecognition(true);
        persistOpenTabs();
        if (backgroundSupport) {
            activityInBackground = true;
            reinforceBackgroundPlayback();
        }
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        activityInBackground = false;
    }

    @Override
    protected void onDestroy() {
        cancelSpeechRecognition(false);
        mediaStateHandler.removeCallbacks(mediaStatePoll);
        mediaStateHandler.removeCallbacks(mediaProbeWatchdog);
        mediaProbeGeneration++;
        if (mediaCommandReceiver != null) {
            try { unregisterReceiver(mediaCommandReceiver); } catch (RuntimeException ignored) { }
        }
        if (fileChooserCallback != null) {
            fileChooserCallback.onReceiveValue(null);
            fileChooserCallback = null;
        }
        if (pendingWebPermissionDialog != null && pendingWebPermissionDialog.isShowing()) {
            pendingWebPermissionDialog.dismiss();
        }
        if (pendingPermissionRequest != null) {
            try { pendingPermissionRequest.deny(); } catch (RuntimeException ignored) { }
            clearPendingWebPermission(false);
        }
        if (privateMode) clearWebStorage(false);
        if (isFinishing() && backgroundSupport) {
            backgroundPlaybackDesired = false;
            setBackgroundMediaPlaybackPolicy(false);
            try {
                startService(new Intent(this, BrowserPlaybackService.class)
                        .setAction(BrowserPlaybackService.ACTION_STOP));
            } catch (RuntimeException ignored) { }
        }
        exitFullscreen();
        for (BrowserTab tab : tabs) {
            try {
                if (tab.webView.getParent() instanceof ViewGroup) ((ViewGroup) tab.webView.getParent()).removeView(tab.webView);
                tab.webView.stopLoading();
                if (tab.speechDocumentStartScript != null) {
                    try { tab.speechDocumentStartScript.remove(); } catch (RuntimeException ignored) { }
                    tab.speechDocumentStartScript = null;
                }
                tab.webView.destroy();
            } catch (RuntimeException ignored) { }
        }
        tabs.clear();
        super.onDestroy();
    }
}
