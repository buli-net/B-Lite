/** Wallet-wide constants. */

package wallet;

public final class Constants {
    private Constants() {
    }

    public static final String WALLET_NAME = "users_wallet";
    public static final String BITCOIN_URI_SCHEME = "bitcoin:";
}
