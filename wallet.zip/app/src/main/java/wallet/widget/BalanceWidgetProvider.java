package wallet.widget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.view.View;
import android.widget.RemoteViews;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

import wallet.main.MainActivity;
import wallet.main.MainActivityPresenter;
import wallet.main.R;
import wallet.qr.QrCodeGenerator;
import wallet.send.SendActivity;

/** Native Android home-screen widget matching the B-Lite balance card. */
public final class BalanceWidgetProvider extends AppWidgetProvider {

    private static final ExecutorService UPDATE_EXECUTOR =
            Executors.newSingleThreadExecutor(r -> {
                Thread thread = new Thread(r, "balance-widget");
                thread.setDaemon(true);
                return thread;
            });
    private static final AtomicBoolean UPDATE_RUNNING = new AtomicBoolean(false);
    private static final AtomicBoolean UPDATE_REQUESTED = new AtomicBoolean(false);
    private static final AtomicReference<String> LAST_RENDER_SIGNATURE = new AtomicReference<>();

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] appWidgetIds) {
        requestRefresh(context);
    }

    /** Requests a coalesced asynchronous widget refresh. Safe to call from bitcoinj threads. */
    public static void requestRefresh(Context context) {
        if (context == null) {
            return;
        }
        final Context app = context.getApplicationContext();
        UPDATE_REQUESTED.set(true);
        if (!UPDATE_RUNNING.compareAndSet(false, true)) {
            return;
        }
        UPDATE_EXECUTOR.execute(() -> {
            try {
                while (UPDATE_REQUESTED.getAndSet(false)) {
                    updateAllWidgets(app);
                }
            } finally {
                UPDATE_RUNNING.set(false);
                if (UPDATE_REQUESTED.get()) {
                    requestRefresh(app);
                }
            }
        });
    }

    private static void updateAllWidgets(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        ComponentName component = new ComponentName(context, BalanceWidgetProvider.class);
        int[] ids = manager.getAppWidgetIds(component);
        if (ids == null || ids.length == 0) {
            return;
        }

        MainActivityPresenter.WidgetSnapshot snapshot =
                MainActivityPresenter.getWidgetSnapshot(context);
        String signature = renderSignature(context, ids, snapshot);
        if (signature.equals(LAST_RENDER_SIGNATURE.get())) {
            return;
        }

        RemoteViews views = createViews(context, snapshot);
        manager.updateAppWidget(component, views);
        LAST_RENDER_SIGNATURE.set(signature);
    }

    private static String renderSignature(
            Context context,
            int[] appWidgetIds,
            MainActivityPresenter.WidgetSnapshot snapshot) {
        StringBuilder builder = new StringBuilder();
        builder.append(context.getResources().getConfiguration().uiMode)
                .append('|');
        if (appWidgetIds != null) {
            for (int id : appWidgetIds) {
                builder.append(id).append(',');
            }
        }
        if (snapshot != null) {
            builder.append('|').append(snapshot.available)
                    .append('|').append(snapshot.balance)
                    .append('|').append(snapshot.availableBalance)
                    .append('|').append(snapshot.pendingBalance)
                    .append('|').append(snapshot.networkLabel)
                    .append('|').append(snapshot.receiveAddress);
        }
        return builder.toString();
    }

    private static RemoteViews createViews(
            Context context,
            MainActivityPresenter.WidgetSnapshot snapshot) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_balance);

        String balance = snapshot == null || !snapshot.available
                ? "--"
                : snapshot.balance;
        String available = snapshot == null || !snapshot.available
                ? "--"
                : snapshot.availableBalance;
        String pending = snapshot == null || !snapshot.available
                ? "--"
                : snapshot.pendingBalance;
        String network = snapshot == null || snapshot.networkLabel == null
                ? ""
                : snapshot.networkLabel;
        String address = snapshot == null ? null : snapshot.receiveAddress;

        views.setTextViewText(R.id.widgetBalance, balance);
        views.setTextViewText(R.id.widgetNetwork, network);
        views.setTextViewText(
                R.id.widgetAvailable,
                context.getString(R.string.available_balance, available));
        views.setTextViewText(
                R.id.widgetPending,
                context.getString(R.string.pending_balance, pending));

        boolean hasAddress = address != null && !address.isEmpty();
        if (hasAddress) {
            try {
                Bitmap qr = QrCodeGenerator.generate(address, 256);
                views.setImageViewBitmap(R.id.widgetQr, qr);
                views.setViewVisibility(R.id.widgetQr, View.VISIBLE);
            } catch (Exception ignored) {
                views.setViewVisibility(R.id.widgetQr, View.INVISIBLE);
            }
        } else {
            views.setViewVisibility(R.id.widgetQr, View.INVISIBLE);
        }

        // All widget colors and shapes are resolved by the widget XML using framework theme attrs.
        // No widget-specific palette or hard-coded colors are used here.
        views.setImageViewResource(R.id.widgetSendIcon, R.drawable.ic_widget_send_24dp);

        PendingIntent openAppPendingIntent = activityPendingIntent(
                context,
                MainActivity.class,
                7101);
        views.setOnClickPendingIntent(R.id.widgetRoot, openAppPendingIntent);

        Intent qrIntent = new Intent(context, MainActivity.class)
                .setAction(MainActivity.ACTION_SHOW_WIDGET_QR)
                .putExtra(MainActivity.EXTRA_WIDGET_QR_ADDRESS, address)
                .setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int qrFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            qrFlags |= PendingIntent.FLAG_IMMUTABLE;
        }
        PendingIntent qrPendingIntent = PendingIntent.getActivity(
                context, 7102, qrIntent, qrFlags);
        views.setOnClickPendingIntent(R.id.widgetQr, qrPendingIntent);

        PendingIntent sendPendingIntent = activityPendingIntent(
                context,
                SendActivity.class,
                7103);
        views.setOnClickPendingIntent(R.id.widgetSend, sendPendingIntent);

        return views;
    }

    private static PendingIntent activityPendingIntent(
            Context context,
            Class<?> activityClass,
            int requestCode) {
        Intent intent = new Intent(context, activityClass)
                .setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        return PendingIntent.getActivity(context, requestCode, intent, flags);
    }

}