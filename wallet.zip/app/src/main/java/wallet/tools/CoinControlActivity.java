package wallet.tools;

import wallet.main.BaseActivity;

import android.os.Bundle;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.bitcoinj.core.TransactionOutput;
import org.bitcoinj.wallet.Wallet;

import java.util.HashMap;
import java.util.Map;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import wallet.main.MainActivityPresenter;
import wallet.main.R;
import wallet.main.WalletSelection;
import wallet.ui.TextViewUtils;

/** Selects specific wallet UTXOs for the next send. */
public final class CoinControlActivity extends BaseActivity {

    private LinearLayout outputsContainer;
    private TextView totalText;
    private Button clearButton;
    private Button applyButton;
    private final Set<String> selected = new HashSet<>();
    private final Map<String, View> coinRows = new HashMap<>();
    private String renderedScope;
    private MainActivityPresenter walletUpdatePresenter;
    private boolean observingWalletUpdates;
    private final Runnable walletUpdateCallback = () -> runOnUiThread(() -> {
        if (observingWalletUpdates && outputsContainer != null && !isFinishing()) {
            render();
        }
    });

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_coin_control);

        Toolbar toolbar = findViewById(R.id.toolbar_coin_control);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(R.string.coin_control_title);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> finish());

        outputsContainer = findViewById(R.id.coinOutputsContainer);
        totalText = findViewById(R.id.coinControlTotal);
        clearButton = findViewById(R.id.clearCoinSelection);
        applyButton = findViewById(R.id.applyCoinSelection);
        clearButton.setOnClickListener(v -> {
            selected.clear();
            render();
        });
        applyButton.setOnClickListener(v -> {
            CoinControl.setSelected(renderedScope, selected);
            Toast.makeText(this, R.string.coin_selection_saved, Toast.LENGTH_SHORT).show();
            finish();
        });

        renderedScope = selectionScope();
        selected.addAll(CoinControl.getSelected(renderedScope));
        render();
    }

    @Override
    protected void onResume() {
        super.onResume();
        observingWalletUpdates = true;
        MainActivityPresenter presenter = MainActivityPresenter.getActivePresenter();
        if (walletUpdatePresenter != presenter) {
            if (walletUpdatePresenter != null) {
                walletUpdatePresenter.removeWalletUpdateListener(walletUpdateCallback);
            }
            walletUpdatePresenter = presenter;
            if (walletUpdatePresenter != null) {
                walletUpdatePresenter.addWalletUpdateListener(walletUpdateCallback);
            }
        }
        if (outputsContainer != null) {
            render();
        }
    }

    @Override
    protected void onPause() {
        observingWalletUpdates = false;
        if (walletUpdatePresenter != null) {
            walletUpdatePresenter.removeWalletUpdateListener(walletUpdateCallback);
            walletUpdatePresenter = null;
        }
        super.onPause();
    }

    private void render() {
        Wallet wallet = MainActivityPresenter.getActiveWallet();
        if (wallet == null) {
            outputsContainer.removeAllViews();
            coinRows.clear();
            totalText.setText(R.string.wallet_not_ready);
            return;
        }

        String currentScope = selectionScope();
        if (!currentScope.equals(renderedScope)) {
            selected.clear();
            CoinControl.clear();
            renderedScope = currentScope;
        }

        org.bitcoinj.script.Script selectedImportedScript =
                WalletSelection.findSelectedImportedScript(this, wallet);
        org.bitcoinj.script.Script selectedWatchScript =
                WalletSelection.findSelectedScript(this, wallet);
        boolean readOnlyWatchSelection = selectedWatchScript != null;
        java.util.Set<org.bitcoinj.script.Script> importedScripts = selectedImportedScript == null
                ? WalletSelection.getImportedScripts(this, wallet)
                : java.util.Collections.emptySet();
        java.util.ArrayList<TransactionOutput> mainOutputs = new java.util.ArrayList<>();
        Set<String> seenOutpoints = new HashSet<>();

        if (selectedImportedScript != null) {
            // Imported wallet scope: exact selected address script only. It may be
            // present in either bitcoinj collection depending on the script type.
            appendMatchingOutputs(mainOutputs, seenOutpoints, wallet.getUnspents(),
                    selectedImportedScript);
            appendMatchingOutputs(mainOutputs, seenOutpoints, wallet.getWatchedOutputs(false),
                    selectedImportedScript);
        } else if (selectedWatchScript != null) {
            // Read-only scope: show only the selected watched address, never main or
            // another watched/imported address. Sending remains disabled elsewhere.
            appendMatchingOutputs(mainOutputs, seenOutpoints, wallet.getWatchedOutputs(false),
                    selectedWatchScript);
            appendMatchingOutputs(mainOutputs, seenOutpoints, wallet.getUnspents(),
                    selectedWatchScript);
        } else {
            // Main-wallet scope: native outputs plus alternate-format Request outputs
            // backed by keys owned by this wallet. Other watched/imported scripts are
            // deliberately excluded even though they share the bitcoinj Wallet object.
            for (TransactionOutput output : wallet.getUnspents()) {
                if (!output.isAvailableForSpending()
                        || WalletSelection.isWatchedOutput(wallet, output)
                        || importedScripts.contains(output.getScriptPubKey())) {
                    continue;
                }
                addUniqueOutput(mainOutputs, seenOutpoints, output);
            }
            java.util.Set<org.bitcoinj.script.Script> requestScripts =
                    WalletSelection.getRequestNestedScripts(this, wallet);
            for (TransactionOutput output : wallet.getWatchedOutputs(false)) {
                org.bitcoinj.script.Script script = output.getScriptPubKey();
                if (!output.isAvailableForSpending()
                        || importedScripts.contains(script)
                        || !requestScripts.contains(script)) {
                    continue;
                }
                addUniqueOutput(mainOutputs, seenOutpoints, output);
            }
        }

        if (clearButton != null) clearButton.setEnabled(!readOnlyWatchSelection);
        if (applyButton != null) applyButton.setEnabled(!readOnlyWatchSelection);
        // Remove stale selections that no longer belong to the currently selected
        // wallet scope or are no longer available for spending.
        selected.removeIf(key -> {
            for (TransactionOutput output : mainOutputs) {
                if (key.equals(CoinControl.key(output))) return false;
            }
            return true;
        });

        long total = 0L;
        Map<String, View> activeRows = new HashMap<>();
        for (TransactionOutput output : mainOutputs) {
            String key = CoinControl.key(output);
            View row = coinRows.get(key);
            if (row == null) {
                row = getLayoutInflater().inflate(
                        R.layout.item_coin_control, outputsContainer, false);
                TextView txId = row.findViewById(R.id.tvCoinTxId);
                TextViewUtils.configureSelectableMiddleEllipsis(txId);
                coinRows.put(key, row);
            }

            CheckBox box = row.findViewById(R.id.coinCheckBox);
            TextView txId = row.findViewById(R.id.tvCoinTxId);
            TextView outputIndex = row.findViewById(R.id.tvCoinOutput);
            TextView confirmations = row.findViewById(R.id.tvCoinConf);
            TextView value = row.findViewById(R.id.tvCoinAmount);

            TextViewUtils.setTextIfChanged(txId, output.getParentTransactionHash().toString());
            TextViewUtils.setTextIfChanged(outputIndex, getString(
                    R.string.watch_send_coin_output, output.getIndex()));
            TextViewUtils.setTextIfChanged(confirmations, getString(
                    R.string.watch_send_coin_confirmations,
                    Math.max(0, output.getParentTransactionDepthInBlocks())));
            TextViewUtils.setTextIfChanged(value, output.getValue().toFriendlyString());

            box.setOnCheckedChangeListener(null);
            box.setChecked(selected.contains(key));
            box.setEnabled(!readOnlyWatchSelection);
            box.setOnCheckedChangeListener((button, checked) -> {
                if (readOnlyWatchSelection) return;
                if (checked) {
                    selected.add(key);
                } else {
                    selected.remove(key);
                }
                updateTotal(mainOutputs);
            });
            row.setOnClickListener(v -> {
                if (!readOnlyWatchSelection) box.setChecked(!box.isChecked());
            });

            activeRows.put(key, row);
            if (selected.contains(key)) {
                total += output.getValue().value;
            }
        }

        java.util.Iterator<Map.Entry<String, View>> iterator = coinRows.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, View> entry = iterator.next();
            if (!activeRows.containsKey(entry.getKey())) {
                outputsContainer.removeView(entry.getValue());
                iterator.remove();
            }
        }

        if (mainOutputs.isEmpty()) {
            outputsContainer.removeAllViews();
            coinRows.clear();
            TextView empty = (TextView) getLayoutInflater().inflate(
                    R.layout.item_empty_message, outputsContainer, false);
            empty.setText(R.string.coin_control_empty);
            outputsContainer.addView(empty);
        } else {
            boolean orderChanged = outputsContainer.getChildCount() != mainOutputs.size();
            if (!orderChanged) {
                for (int i = 0; i < mainOutputs.size(); i++) {
                    View expected = activeRows.get(CoinControl.key(mainOutputs.get(i)));
                    if (outputsContainer.getChildAt(i) != expected) {
                        orderChanged = true;
                        break;
                    }
                }
            }
            if (orderChanged) {
                outputsContainer.removeAllViews();
                for (TransactionOutput output : mainOutputs) {
                    View row = activeRows.get(CoinControl.key(output));
                    if (row != null) outputsContainer.addView(row);
                }
            }
        }

        totalText.setText(getString(
                R.string.coin_control_selected_total,
                org.bitcoinj.base.Coin.valueOf(total).toFriendlyString()));
    }

    private String selectionScope() {
        return WalletSelection.getSelectionScope(
                this, MainActivityPresenter.getActiveWallet());
    }

    private void appendMatchingOutputs(
            List<TransactionOutput> destination, Set<String> seenOutpoints,
            Iterable<TransactionOutput> candidates, org.bitcoinj.script.Script requiredScript) {
        if (candidates == null || requiredScript == null) return;
        for (TransactionOutput output : candidates) {
            if (!output.isAvailableForSpending()
                    || !requiredScript.equals(output.getScriptPubKey())) {
                continue;
            }
            addUniqueOutput(destination, seenOutpoints, output);
        }
    }

    private void addUniqueOutput(
            List<TransactionOutput> destination, Set<String> seenOutpoints,
            TransactionOutput output) {
        if (seenOutpoints.add(CoinControl.key(output))) {
            destination.add(output);
        }
    }

    private void updateTotal(List<TransactionOutput> outputs) {
        long total = 0L;
        for (TransactionOutput output : outputs) {
            if (selected.contains(CoinControl.key(output))) {
                total += output.getValue().value;
            }
        }
        totalText.setText(getString(
                R.string.coin_control_selected_total,
                org.bitcoinj.base.Coin.valueOf(total).toFriendlyString()));
    }
}
