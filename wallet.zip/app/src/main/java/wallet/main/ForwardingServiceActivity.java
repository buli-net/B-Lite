package wallet.main;

import android.os.Bundle;
import android.content.SharedPreferences;
import android.content.ClipboardManager;
import android.content.ClipData;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;

import org.bitcoinj.base.Address;
import org.bitcoinj.base.AddressParser;
import org.bitcoinj.base.BitcoinNetwork;
import org.bitcoinj.base.Coin;

/** Configuration screen for opt-in automatic forwarding from the active wallet. */
public class ForwardingServiceActivity extends BaseActivity {
    private static final String PREFS = "forwarding_service";
    private static final String ENABLED = "enabled";
    private static final String DESTINATION = "destination";
    private static final String CONFIRMATIONS = "confirmations";
    private static final String STATUS = "status";
    private static final String MODE = "mode";
    private static final String FIXED_AMOUNT_SATS = "fixed_amount_sats";
    private static final String FEE_RATE_SAT_VB = "fee_rate_sat_vb";
    private static final String LAST_FEE_SATS = "last_fee_sats";
    private static final String LAST_AMOUNT_SATS = "last_amount_sats";
    private static final String LAST_RATE_SAT_VB = "last_rate_sat_vb";
    private static final String LAST_EFFECTIVE_RATE_SAT_VB = "last_effective_rate_sat_vb";
    private static final String LAST_VSIZE = "last_vsize";
    private static final String LAST_INCOMING_TX = "last_incoming_tx";
    private static final String LAST_OUTGOING_TX = "last_outgoing_tx";
    private static final String LAST_STAGE = "last_stage";
    private static final String LAST_RECEIVED_SATS = "last_received_sats";
    private static final String LAST_CURRENT_CONFIRMATIONS = "last_current_confirmations";
    private static final String LAST_REQUIRED_CONFIRMATIONS = "last_required_confirmations";
    private static final String LAST_OUTGOING_CONFIRMATIONS = "last_outgoing_confirmations";

    private EditText destination;
    private EditText confirmations;
    private TextView network;
    private TextView status;
    private Button toggle;
    private EditText fixedAmount;
    private RadioGroup modeChoice;
    private SeekBar feeRate;
    private TextView feeRateLabel;
    private TextView feePreview;
    private TextView activityTitle;
    private TextView activityDetail;
    private TextView activityConfirmations;
    private TextView incomingTxValue;
    private TextView outgoingTxValue;
    private TextView amountSummary;
    private TextView copyIncomingTx;
    private TextView copyOutgoingTx;
    private View incomingTxRow;
    private View outgoingTxRow;
    private View confirmationsRow;
    private ProgressBar confirmationProgress;
    private View fixedAmountContainer;
    private SharedPreferences.OnSharedPreferenceChangeListener preferencesListener;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_forwarding_service);

        Toolbar toolbar = findViewById(R.id.toolbar_forwarding_service);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(R.string.forwarding_service_title);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> finish());

        destination = findViewById(R.id.forwardingDestination);
        confirmations = findViewById(R.id.forwardingConfirmations);
        network = findViewById(R.id.forwardingNetwork);
        status = findViewById(R.id.forwardingStatus);
        toggle = findViewById(R.id.forwardingToggleButton);
        fixedAmount = findViewById(R.id.forwardingFixedAmount);
        modeChoice = findViewById(R.id.forwardingModeChoice);
        fixedAmountContainer = findViewById(R.id.forwardingFixedAmountContainer);
        feeRate = findViewById(R.id.forwardingFeeRate);
        feeRateLabel = findViewById(R.id.forwardingFeeRateLabel);
        feePreview = findViewById(R.id.forwardingActivityFeeSummary);
        activityTitle = findViewById(R.id.forwardingActivityTitle);
        activityDetail = findViewById(R.id.forwardingActivityDetail);
        activityConfirmations = findViewById(R.id.forwardingActivityConfirmations);
        incomingTxValue = findViewById(R.id.forwardingIncomingTxValue);
        outgoingTxValue = findViewById(R.id.forwardingOutgoingTxValue);
        amountSummary = findViewById(R.id.forwardingActivityAmountSummary);
        copyIncomingTx = findViewById(R.id.forwardingCopyIncomingTx);
        copyOutgoingTx = findViewById(R.id.forwardingCopyOutgoingTx);
        incomingTxRow = findViewById(R.id.forwardingIncomingTxRow);
        outgoingTxRow = findViewById(R.id.forwardingOutgoingTxRow);
        confirmationsRow = findViewById(R.id.forwardingConfirmationsRow);
        confirmationProgress = findViewById(R.id.forwardingConfirmationProgress);
        copyIncomingTx.setOnClickListener(v -> copyTransactionId(
                getSharedPreferences(PREFS, MODE_PRIVATE).getString(LAST_INCOMING_TX, "")));
        copyOutgoingTx.setOnClickListener(v -> copyTransactionId(
                getSharedPreferences(PREFS, MODE_PRIVATE).getString(LAST_OUTGOING_TX, "")));
        incomingTxValue.setOnClickListener(v -> copyTransactionId(
                getSharedPreferences(PREFS, MODE_PRIVATE).getString(LAST_INCOMING_TX, "")));
        outgoingTxValue.setOnClickListener(v -> copyTransactionId(
                getSharedPreferences(PREFS, MODE_PRIVATE).getString(LAST_OUTGOING_TX, "")));
        Button save = findViewById(R.id.forwardingSaveButton);

        destination.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        confirmations.setInputType(InputType.TYPE_CLASS_NUMBER);
        fixedAmount.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        feeRate.setMax(9); // Send screen supports 1-10 sat/vB.
        feeRate.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                updateFeeRateLabel();
            }
            @Override public void onStartTrackingTouch(SeekBar bar) { }
            @Override public void onStopTrackingTouch(SeekBar bar) { }
        });
        modeChoice.setOnCheckedChangeListener((group, checkedId) -> updateModeVisibility());
        save.setOnClickListener(v -> saveSettings());
        toggle.setOnClickListener(v -> toggleForwarding());
        preferencesListener = (sharedPreferences, key) -> {
            if (status != null && feePreview != null) updateState();
        };
        loadSettings();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getSharedPreferences(PREFS, MODE_PRIVATE).registerOnSharedPreferenceChangeListener(preferencesListener);
        if (status != null) updateState();
    }

    @Override
    protected void onPause() {
        getSharedPreferences(PREFS, MODE_PRIVATE).unregisterOnSharedPreferenceChangeListener(preferencesListener);
        super.onPause();
    }

    private void loadSettings() {
        android.content.SharedPreferences preferences = getSharedPreferences(PREFS, MODE_PRIVATE);
        destination.setText(preferences.getString(DESTINATION, ""));
        confirmations.setText(String.valueOf(preferences.getInt(CONFIRMATIONS, 1)));
        String mode = preferences.getString(MODE, "sweep");
        modeChoice.check("fixed".equals(mode) ? R.id.forwardingModeFixed : R.id.forwardingModeSweep);
        long fixedSats = preferences.getLong(FIXED_AMOUNT_SATS, 0L);
        fixedAmount.setText(fixedSats > 0L
                ? MoneyFormatter.formatInput(this, Coin.valueOf(fixedSats)) : "");
        feeRate.setProgress(Math.max(0, Math.min(9,
                preferences.getInt(FEE_RATE_SAT_VB, 5) - 1)));
        updateFeeRateLabel();
        updateModeVisibility();
        updateState();
    }

    private boolean saveSettings() {
        Address parsed;
        int confirmationCount;
        try {
            parsed = AddressParser.getDefault().parseAddress(destination.getText().toString().trim());
            NetworkConfig.get(this).checkAddress(parsed);
        } catch (Exception error) {
            destination.setError(getString(R.string.forwarding_invalid_address));
            Toast.makeText(this, R.string.forwarding_invalid_address, Toast.LENGTH_LONG).show();
            return false;
        }

        try {
            confirmationCount = Integer.parseInt(confirmations.getText().toString().trim());
            if (confirmationCount < 1 || confirmationCount > 100) {
                throw new NumberFormatException("confirmation count out of range");
            }
        } catch (NumberFormatException error) {
            confirmations.setError(getString(R.string.forwarding_invalid_confirmations));
            Toast.makeText(this, R.string.forwarding_invalid_confirmations, Toast.LENGTH_LONG).show();
            return false;
        }

        String selectedMode = modeChoice.getCheckedRadioButtonId() == R.id.forwardingModeFixed
                ? "fixed" : "sweep";
        long fixedAmountSats = 0L;
        if ("fixed".equals(selectedMode)) {
            try {
                Coin amount = MoneyFormatter.parse(this, fixedAmount.getText().toString());
                if (amount.value <= 0L) throw new IllegalArgumentException("amount must be positive");
                fixedAmountSats = amount.value;
            } catch (Exception error) {
                fixedAmount.setError(getString(R.string.forwarding_invalid_fixed_amount));
                Toast.makeText(this, R.string.forwarding_invalid_fixed_amount, Toast.LENGTH_LONG).show();
                return false;
            }
        }
        int feeRateSatVb = feeRate.getProgress() + 1;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString(DESTINATION, parsed.toString())
                .putInt(CONFIRMATIONS, confirmationCount)
                .putString(MODE, selectedMode)
                .putLong(FIXED_AMOUNT_SATS, fixedAmountSats)
                .putInt(FEE_RATE_SAT_VB, feeRateSatVb)
                .apply();
        destination.setError(null);
        confirmations.setError(null);
        fixedAmount.setError(null);
        Toast.makeText(this, R.string.forwarding_saved, Toast.LENGTH_SHORT).show();
        updateState();
        return true;
    }

    private void updateModeVisibility() {
        if (fixedAmountContainer == null || modeChoice == null) return;
        fixedAmountContainer.setVisibility(modeChoice.getCheckedRadioButtonId() == R.id.forwardingModeFixed
                ? View.VISIBLE : View.GONE);
    }

    private void updateFeeRateLabel() {
        if (feeRateLabel != null && feeRate != null) {
            feeRateLabel.setText(getString(R.string.forwarding_fee_rate_value, feeRate.getProgress() + 1));
        }
    }

    private void toggleForwarding() {
        android.content.SharedPreferences preferences = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (preferences.getBoolean(ENABLED, false)) {
            android.content.SharedPreferences.Editor editor = preferences.edit()
                    .putBoolean(ENABLED, false)
                    .putString(STATUS, "");
            if ("waiting".equals(preferences.getString(LAST_STAGE, ""))) {
                editor.putString(LAST_STAGE, "disabled");
            }
            editor.apply();
            updateState();
            return;
        }

        if (MainActivityPresenter.getActiveWallet() == null) {
            Toast.makeText(this, R.string.forwarding_wallet_unavailable, Toast.LENGTH_LONG).show();
            return;
        }
        if (!saveSettings()) return;

        new AlertDialog.Builder(this)
                .setTitle(R.string.forwarding_confirm_title)
                .setMessage(R.string.forwarding_confirm_message)
                .setNegativeButton(android.R.string.cancel, null)
                .setPositiveButton(R.string.forwarding_enable, (dialog, which) -> {
                    preferences.edit()
                            .putBoolean(ENABLED, true)
                            .putString(STATUS, "")
                            .apply();
                    updateState();
                })
                .show();
    }

    private void updateState() {
        android.content.SharedPreferences preferences = getSharedPreferences(PREFS, MODE_PRIVATE);
        boolean enabled = preferences.getBoolean(ENABLED, false);
        String lastStatus = preferences.getString(STATUS, "");
        BitcoinNetwork currentNetwork = NetworkConfig.get(this);
        network.setText(getString(R.string.forwarding_network_value, currentNetwork.toString()));
        status.setText(enabled
                ? getString(R.string.forwarding_status_enabled)
                : getString(R.string.forwarding_status_off));

        String stage = preferences.getString(LAST_STAGE, "");
        String incomingTx = preferences.getString(LAST_INCOMING_TX, "");
        String outgoingTx = preferences.getString(LAST_OUTGOING_TX, "");
        boolean trackingOutgoingConfirmation = "relayed".equals(stage) || "confirmed".equals(stage);
        int required = trackingOutgoingConfirmation ? 1 : Math.max(1,
                preferences.getInt(LAST_REQUIRED_CONFIRMATIONS, preferences.getInt(CONFIRMATIONS, 1)));
        int current = trackingOutgoingConfirmation
                ? Math.max(0, Math.min(1, preferences.getInt(LAST_OUTGOING_CONFIRMATIONS, 0)))
                : Math.max(0, Math.min(required,
                        preferences.getInt(LAST_CURRENT_CONFIRMATIONS, 0)));

        if (stage.isEmpty()) {
            activityTitle.setText(R.string.forwarding_activity_idle_title);
            activityDetail.setText(R.string.forwarding_activity_idle_detail);
        } else if ("waiting".equals(stage)) {
            activityTitle.setText(R.string.forwarding_activity_waiting_title);
            activityDetail.setText(R.string.forwarding_activity_waiting_detail);
        } else if ("preparing".equals(stage)) {
            activityTitle.setText(R.string.forwarding_activity_preparing_title);
            activityDetail.setText(R.string.forwarding_activity_preparing_detail);
        } else if ("broadcasting".equals(stage)) {
            activityTitle.setText(R.string.forwarding_activity_broadcasting_title);
            activityDetail.setText(R.string.forwarding_activity_broadcasting_detail);
        } else if ("relayed".equals(stage)) {
            activityTitle.setText(R.string.forwarding_activity_relayed_title);
            activityDetail.setText(R.string.forwarding_activity_relayed_detail);
        } else if ("confirmed".equals(stage)) {
            activityTitle.setText(R.string.forwarding_activity_confirmed_title);
            activityDetail.setText(R.string.forwarding_activity_confirmed_detail);
        } else if ("failed".equals(stage)) {
            activityTitle.setText(R.string.forwarding_activity_failed_title);
            String failureDetail = lastStatus.isEmpty()
                    ? getString(R.string.forwarding_activity_failed_detail) : lastStatus;
            if (!incomingTx.isEmpty()) failureDetail = failureDetail.replace(incomingTx, compactTxId(incomingTx));
            if (!outgoingTx.isEmpty()) failureDetail = failureDetail.replace(outgoingTx, compactTxId(outgoingTx));
            activityDetail.setText(failureDetail);
        } else if ("disabled".equals(stage)) {
            activityTitle.setText(R.string.forwarding_activity_disabled_title);
            activityDetail.setText(R.string.forwarding_activity_disabled_detail);
        } else {
            activityTitle.setText(R.string.forwarding_activity_idle_title);
            activityDetail.setText(R.string.forwarding_activity_idle_detail);
        }

        boolean hasIncoming = !stage.isEmpty() && !incomingTx.isEmpty();
        boolean hasOutgoing = !stage.isEmpty() && !outgoingTx.isEmpty();
        incomingTxRow.setVisibility(hasIncoming ? View.VISIBLE : View.GONE);
        outgoingTxRow.setVisibility(hasOutgoing ? View.VISIBLE : View.GONE);
        incomingTxValue.setText(hasIncoming ? compactTxId(incomingTx) : "");
        outgoingTxValue.setText(hasOutgoing ? compactTxId(outgoingTx) : "");

        boolean showProgress = "waiting".equals(stage) || "preparing".equals(stage)
                || "broadcasting".equals(stage) || "relayed".equals(stage) || "confirmed".equals(stage);
        confirmationsRow.setVisibility(showProgress ? View.VISIBLE : View.GONE);
        if (showProgress) {
            activityConfirmations.setText(getString(trackingOutgoingConfirmation
                            ? R.string.forwarding_activity_outgoing_confirmation_count
                            : R.string.forwarding_activity_confirmation_count,
                    current, required));
            confirmationProgress.setMax(required);
            confirmationProgress.setProgress(current);
        }

        long receivedSats = preferences.getLong(LAST_RECEIVED_SATS, -1L);
        long feeSats = preferences.getLong(LAST_FEE_SATS, -1L);
        long amountSats = preferences.getLong(LAST_AMOUNT_SATS, -1L);
        int rate = preferences.getInt(LAST_RATE_SAT_VB, -1);
        int effectiveRate = preferences.getInt(LAST_EFFECTIVE_RATE_SAT_VB, -1);
        int vsize = preferences.getInt(LAST_VSIZE, 0);
        if (!stage.isEmpty() && (receivedSats >= 0L || amountSats > 0L)) {
            String received = receivedSats >= 0L
                    ? MoneyFormatter.format(this, Coin.valueOf(receivedSats))
                    : getString(R.string.forwarding_value_unavailable);
            String amount = amountSats > 0L
                    ? MoneyFormatter.format(this, Coin.valueOf(amountSats))
                    : getString(R.string.forwarding_value_unavailable);
            amountSummary.setText(getString(R.string.forwarding_activity_amounts, received, amount));
        } else {
            amountSummary.setText(R.string.forwarding_activity_amounts_empty);
        }
        if (!stage.isEmpty() && feeSats >= 0L && rate > 0) {
            feePreview.setText(getString(R.string.forwarding_activity_fee_summary,
                    MoneyFormatter.format(this, Coin.valueOf(feeSats)), rate, effectiveRate, vsize));
        } else {
            feePreview.setText(R.string.forwarding_activity_fee_empty);
        }
        toggle.setText(enabled ? R.string.forwarding_disable : R.string.forwarding_enable);
    }

    private String compactTxId(String txId) {
        if (txId == null || txId.length() <= 24) return txId == null ? "" : txId;
        return txId.substring(0, 12) + "…" + txId.substring(txId.length() - 12);
    }

    private void copyTransactionId(String txId) {
        if (txId == null || txId.trim().isEmpty()) {
            Toast.makeText(this, R.string.forwarding_no_txid_to_copy, Toast.LENGTH_SHORT).show();
            return;
        }
        ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (clipboard != null) {
            clipboard.setPrimaryClip(ClipData.newPlainText("Bitcoin transaction ID", txId));
            Toast.makeText(this, R.string.forwarding_txid_copied, Toast.LENGTH_SHORT).show();
        }
    }

}
