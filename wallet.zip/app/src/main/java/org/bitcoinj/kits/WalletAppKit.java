/*
 * Copyright 2013 Google Inc.
 * Copyright 2014 Andreas Schildbach
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.bitcoinj.kits;

import com.google.common.io.Closeables;
import com.google.common.util.concurrent.AbstractIdleService;
import org.bitcoinj.base.BitcoinNetwork;
import org.bitcoinj.base.ScriptType;
import org.bitcoinj.base.Sha256Hash;
import org.bitcoinj.base.internal.PlatformUtils;
import org.bitcoinj.core.AbstractBlockChain;
import org.bitcoinj.core.BlockChain;
import org.bitcoinj.core.FullPrunedBlockChain;
import org.bitcoinj.core.CheckpointManager;
import org.bitcoinj.core.Context;
import org.bitcoinj.core.NetworkParameters;
import org.bitcoinj.core.PeerAddress;
import org.bitcoinj.core.StoredBlock;
import org.bitcoinj.core.PeerGroup;
import org.bitcoinj.core.Services;
import org.bitcoinj.core.listeners.DownloadProgressTracker;
import org.bitcoinj.crypto.DeterministicKey;
import org.bitcoinj.net.discovery.DnsDiscovery;
import org.bitcoinj.net.discovery.PeerDiscovery;
import org.bitcoinj.store.BlockStore;
import org.bitcoinj.store.FullPrunedBlockStore;
import org.bitcoinj.store.SQLiteFullPrunedBlockStore;
import org.bitcoinj.store.BlockStoreException;
import org.bitcoinj.store.SPVBlockStore;
import org.bitcoinj.wallet.DeterministicSeed;
import org.bitcoinj.wallet.KeyChainGroup;
import org.bitcoinj.wallet.KeyChainGroupStructure;
import org.bitcoinj.wallet.Wallet;
import org.bitcoinj.wallet.WalletExtension;
import org.bitcoinj.wallet.WalletProtobufSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.channels.FileLock;
import java.time.Duration;
import java.time.Instant;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import static org.bitcoinj.base.internal.Preconditions.checkState;

/**
 * <p>Utility class that wraps the boilerplate needed to set up a bitcoinj wallet app. Instantiate it with a directory
 * and file prefix, optionally configure a few things, then use startAsync and optionally awaitRunning. The object
 * constructs either an SPV {@link BlockChain} backed by {@link SPVBlockStore}, or a {@link FullPrunedBlockChain}
 * backed by a durable SQLite UTXO store, together with the {@link Wallet} and {@link PeerGroup}. Depending on the
 * value of the blockingStartup property, startup will be considered complete once the block chain has fully
 * synchronized, so it can take a while.</p>
 *
 * <p>To add listeners and modify the objects that are constructed, you can either do that by overriding the
 * {@link #onSetupCompleted()} method (which will run on a background thread) and make your changes there,
 * or by waiting for the service to start and then accessing the objects from wherever you want. However, you cannot
 * access the objects this class creates until startup is complete.</p>
 *
 * <p>The asynchronous design of this class may seem puzzling (just use {@link #awaitRunning()} if you don't want that).
 * It is to make it easier to fit bitcoinj into GUI apps, which require a high degree of responsiveness on their main
 * thread which handles all the animation and user interaction. Even when blockingStart is false, initializing bitcoinj
 * means doing potentially blocking file IO, generating keys and other potentially intensive operations. By running it
 * on a background thread, there's no risk of accidentally causing UI lag.</p>
 *
 * <p>Note that {@link #awaitRunning()} can throw an unchecked {@link IllegalStateException}
 * if anything goes wrong during startup - you should probably handle it and use {@link Exception#getCause()} to figure
 * out what went wrong more precisely. Same thing if you just use the {@link #startAsync()} method.</p>
 */
public class WalletAppKit extends AbstractIdleService implements Closeable {
    protected static final Logger log = LoggerFactory.getLogger(WalletAppKit.class);

    protected final BitcoinNetwork network;
    protected final NetworkParameters params;
    protected final ScriptType preferredOutputScriptType;
    protected final KeyChainGroupStructure structure;
    protected final String filePrefix;
    protected volatile AbstractBlockChain vChain;
    protected volatile BlockStore vStore;
    protected volatile FullPrunedBlockStore vFullPrunedStore;
    // Optional marker used when an application adds a persistent history index that must be populated
    // by replaying the verified full chain once. The wallet file and transaction history are preserved.
    private File fullPrunedHistoryIndexMarker;
    private boolean forceFullPrunedHistoryIndexRebuild;
    protected boolean fullPrunedValidation;
    protected volatile Wallet vWallet;
    protected volatile PeerGroup vPeerGroup;

    protected final File directory;
    protected volatile File vWalletFile;

    protected boolean useAutoSave = true;
    protected PeerAddress[] peerAddresses;
    protected DownloadProgressTracker downloadListener = new DownloadProgressTracker();
    protected boolean autoStop = true;
    protected InputStream checkpoints;
    protected boolean blockingStartup = true;
    protected String userAgent, version;
    @Nonnull protected WalletProtobufSerializer.WalletFactory walletFactory = WalletProtobufSerializer.WalletFactory.DEFAULT;
    @Nullable protected DeterministicSeed restoreFromSeed;
    @Nullable protected DeterministicKey restoreFromKey;
    @Nullable protected PeerDiscovery discovery;

    /**
     * Creates a new WalletAppKit, with a newly created {@link Context}. Files will be stored in the given directory.
     * @deprecated Use {@link #WalletAppKit(BitcoinNetwork, ScriptType, KeyChainGroupStructure, File, String)}
     */
    @Deprecated
    public WalletAppKit(NetworkParameters params, File directory, String filePrefix) {
        this((BitcoinNetwork) params.network(), ScriptType.P2PKH, KeyChainGroupStructure.BIP32, directory, filePrefix);
    }

    /**
     * Creates a new WalletAppKit, with a newly created {@link Context}. Files will be stored in the given directory.
     * @deprecated Use {@link #WalletAppKit(BitcoinNetwork, ScriptType, KeyChainGroupStructure, File, String)}
     */
    @Deprecated
    public WalletAppKit(NetworkParameters params, ScriptType preferredOutputScriptType,
            @Nullable KeyChainGroupStructure structure, File directory, String filePrefix) {
        this((BitcoinNetwork) params.network(), preferredOutputScriptType, structure, directory, filePrefix);
    }

    /**
     * Creates a new WalletAppKit, on the specified {@link BitcoinNetwork}. Files will be stored in the given directory.
     *
     * @param network The network the wallet connects to
     * @param preferredOutputScriptType The output script type (and therefore {@code Address} type) of the wallet
     * @param structure The keychain group structure (e.g. {@link KeyChainGroupStructure#BIP43} or {@link KeyChainGroupStructure#BIP32}
     * @param directory The directory for creating the wallet file and the selected chain-store file
     * @param filePrefix The base name for the wallet file and the selected chain-store file
     */
    public WalletAppKit(BitcoinNetwork network, ScriptType preferredOutputScriptType,
                        KeyChainGroupStructure structure, File directory, String filePrefix) {
        this.network = Objects.requireNonNull(network);
        this.params = NetworkParameters.of(this.network);
        this.preferredOutputScriptType = Objects.requireNonNull(preferredOutputScriptType);
        this.structure = Objects.requireNonNull(structure);
        this.directory = Objects.requireNonNull(directory);
        this.filePrefix = Objects.requireNonNull(filePrefix);
    }

    /**
     * Launch an instance of WalletAppKit with asynchronous startup. Wait until the PeerGroup is initialized.
     *
     * @param network The network the wallet connects to
     * @param directory The directory for creating the wallet file and the selected chain-store file
     * @param filePrefix The base name for the wallet file and the selected chain-store file
     * @return the instance
     */
    public static WalletAppKit launch(BitcoinNetwork network, File directory, String filePrefix) {
        return WalletAppKit.launch(network, directory, filePrefix, 0);
    }

    /**
     * Launch an instance of WalletAppKit with asynchronous startup. Wait until the PeerGroup is initialized.
     *
     * @param network The network the wallet connects to
     * @param directory The directory for creating the wallet file and the selected chain-store file
     * @param filePrefix The base name for the wallet file and the selected chain-store file
     * @param configurer Callback to allow configuring the kit before it is started
     * @return the instance
     */
    public static WalletAppKit launch(BitcoinNetwork network, File directory, String filePrefix, Consumer<WalletAppKit> configurer) {
        return WalletAppKit.launch(network, directory, filePrefix, configurer, 0);
    }

    /**
     * Launch an instance of WalletAppKit with asynchronous startup. Wait until the PeerGroup is initialized.
     *
     * @param network The network the wallet connects to
     * @param directory The directory for creating the wallet file and the selected chain-store file
     * @param filePrefix The base name for the wallet file and the selected chain-store file
     * @param maxConnections maximum number of peer connections.
     * @return the instance
     */
    public static WalletAppKit launch(BitcoinNetwork network, File directory, String filePrefix, int maxConnections) {
        return WalletAppKit.launch(network, directory, filePrefix, (c) -> {}, maxConnections);
    }

    /**
     * Launch an instance of WalletAppKit with asynchronous startup. Wait until the PeerGroup is initialized.
     *
     * @param network The network the wallet connects to
     * @param directory The directory for creating the wallet file and the selected chain-store file
     * @param filePrefix The base name for the wallet file and the selected chain-store file
     * @param configurer Callback to allow configuring the kit before it is started
     * @param maxConnections maximum number of peer connections.
     * @return the instance
     */
    public static WalletAppKit launch(BitcoinNetwork network, File directory, String filePrefix, Consumer<WalletAppKit> configurer, int maxConnections) {
        WalletAppKit kit = new WalletAppKit(network,
                ScriptType.P2WPKH,
                KeyChainGroupStructure.BIP32,
                directory,
                filePrefix);

        if (network == BitcoinNetwork.REGTEST) {
            // Regression test mode is designed for testing and development only, so there's no public network for it.
            // If you pick this mode, you're expected to be running a local "bitcoind -regtest" instance.
            kit.connectToLocalHost();
        }

        kit.setBlockingStartup(false);  // Don't wait for blockchain synchronization before entering RUNNING state
        configurer.accept(kit);         // Call configurer before startup
        kit.startAsync();               // Connect to the network and start downloading transactions
        kit.awaitRunning();             // Wait for the service to reach the RUNNING state
        if (maxConnections > 0) {
            kit.peerGroup().setMaxConnections(maxConnections);
        }
        return kit;
    }

    /** Will only connect to the given addresses. Cannot be called after startup. */
    public WalletAppKit setPeerNodes(PeerAddress... addresses) {
        checkState(state() == State.NEW, () ->
                "cannot call after startup");
        this.peerAddresses = addresses;
        return this;
    }

    /** Will only connect to localhost. Cannot be called after startup. */
    public WalletAppKit connectToLocalHost() {
        return setPeerNodes(PeerAddress.localhost(params));
    }

    /** Enable full block and transaction validation with a durable on-device UTXO database. */
    public WalletAppKit setFullPrunedValidation(boolean value) {
        checkState(state() == State.NEW, () -> "cannot call after startup");
        fullPrunedValidation = value;
        return this;
    }

    /**
     * Configures the completion marker for the wallet-scoped Full Pruned input-history index.
     * A sibling ".building" marker makes a genesis replay resumable across process death; the
     * ".ready" marker is written only after the verified chain has caught up. Neither marker is
     * part of the wallet backup and neither changes keys, transactions, or wallet identity.
     */
    public WalletAppKit setFullPrunedHistoryIndexMarker(File marker) {
        checkState(state() == State.NEW, () -> "cannot call after startup");
        fullPrunedHistoryIndexMarker = marker;
        return this;
    }

    /** Force a full store replay after the per-network input-history table had to be discarded. */
    public WalletAppKit setForceFullPrunedHistoryIndexRebuild(boolean value) {
        checkState(state() == State.NEW, () -> "cannot call after startup");
        forceFullPrunedHistoryIndexRebuild = value;
        return this;
    }

    /** Persistently marks the input-history index incomplete after any input cannot be indexed. */
    public void reportFullPrunedHistoryIndexFailure() throws IOException {
        if (!fullPrunedValidation || fullPrunedHistoryIndexMarker == null) return;
        File parent = fullPrunedHistoryIndexMarker.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs() && !parent.isDirectory())
            throw new IOException("Could not create Full Pruned history marker directory: " + parent);
        if (fullPrunedHistoryIndexMarker.exists() && !fullPrunedHistoryIndexMarker.delete())
            throw new IOException("Could not revoke Full Pruned history ready marker: " + fullPrunedHistoryIndexMarker);
        File building = fullPrunedHistoryBuildingMarker();
        if (building != null && !building.exists() && !building.createNewFile() && !building.exists())
            throw new IOException("Could not persist Full Pruned history building marker: " + building);
        File failed = fullPrunedHistoryFailureMarker();
        if (!failed.exists() && !failed.createNewFile() && !failed.exists())
            throw new IOException("Could not persist Full Pruned history failure marker: " + failed);
    }

    /**
     * Marks the history index ready only after Full Pruned has reached one consistent verified tip.
     * Call from the download-complete callback, not immediately after clearing the store.
     */
    public void markFullPrunedHistoryIndexReady() throws IOException, BlockStoreException {
        if (!fullPrunedValidation || fullPrunedHistoryIndexMarker == null) return;
        FullPrunedBlockStore store = vFullPrunedStore;
        AbstractBlockChain chain = vChain;
        if (store == null || chain == null || vWallet == null)
            throw new IOException("Full Pruned history index cannot be completed before startup");
        File failedMarker = fullPrunedHistoryFailureMarker();
        if (failedMarker != null && failedMarker.exists())
            throw new IOException("Full Pruned input-history indexing failed; ready marker must not be committed");
        StoredBlock verifiedHead = store.getVerifiedChainHead();
        StoredBlock chainHead = chain.getChainHead();
        if (verifiedHead == null || chainHead == null || verifiedHead.getHeader() == null
                || chainHead.getHeader() == null
                || verifiedHead.getHeight() != chainHead.getHeight()
                || !verifiedHead.getHeader().getHash().equals(chainHead.getHeader().getHash())) {
            throw new IOException("Full Pruned chain and verified UTXO head are not aligned");
        }
        File parent = fullPrunedHistoryIndexMarker.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs() && !parent.isDirectory())
            throw new IOException("Could not create Full Pruned history marker directory: " + parent);
        if (!fullPrunedHistoryIndexMarker.exists()
                && !fullPrunedHistoryIndexMarker.createNewFile()
                && !fullPrunedHistoryIndexMarker.exists()) {
            throw new IOException("Could not persist Full Pruned history ready marker: " + fullPrunedHistoryIndexMarker);
        }
        File buildingMarker = fullPrunedHistoryBuildingMarker();
        if (buildingMarker != null && buildingMarker.exists() && !buildingMarker.delete())
            log.warn("Full Pruned history ready marker committed but stale building marker could not be removed: {}", buildingMarker);
    }

    private File fullPrunedHistoryBuildingMarker() {
        return fullPrunedHistoryIndexMarker == null ? null
                : new File(fullPrunedHistoryIndexMarker.getPath() + ".building");
    }

    private File fullPrunedHistoryFailureMarker() {
        return fullPrunedHistoryIndexMarker == null ? null
                : new File(fullPrunedHistoryIndexMarker.getPath() + ".failed");
    }

    /**
     * Persist the in-progress marker before any intentional genesis replay. Otherwise a force-stop
     * between clearing SQLite and creating the marker could make every subsequent launch start
     * another replay from genesis.
     */
    private void beginFullPrunedHistoryIndexBuildBeforeReset() throws IOException {
        if (fullPrunedHistoryIndexMarker == null) return;
        if (fullPrunedHistoryIndexMarker.exists() && !fullPrunedHistoryIndexMarker.delete())
            throw new IOException("Could not revoke stale Full Pruned history ready marker before replay: "
                    + fullPrunedHistoryIndexMarker);
        File building = fullPrunedHistoryBuildingMarker();
        File parent = building == null ? null : building.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs() && !parent.isDirectory())
            throw new IOException("Could not create Full Pruned history marker directory: " + parent);
        if (building != null && !building.exists() && !building.createNewFile() && !building.exists())
            throw new IOException("Could not persist Full Pruned history building marker before replay: " + building);
    }

    /** True only when wallet checkpoint is on the current verified branch at its stored height. */
    private boolean isWalletCheckpointAncestor(FullPrunedBlockStore store, StoredBlock verifiedHead,
                                               int walletHeight, Sha256Hash walletHash)
            throws BlockStoreException {
        if (store == null || verifiedHead == null || walletHeight < 0 || walletHash == null
                || walletHeight > verifiedHead.getHeight()) return false;
        StoredBlock cursor = verifiedHead;
        while (cursor != null && cursor.getHeight() > walletHeight) {
            cursor = cursor.getPrev(store);
        }
        return cursor != null && cursor.getHeight() == walletHeight
                && walletHash.equals(cursor.getHeader().getHash());
    }

    /** If true, the wallet will save itself to disk automatically whenever it changes. */
    public WalletAppKit setAutoSave(boolean value) {
        checkState(state() == State.NEW, () ->
                "cannot call after startup");
        useAutoSave = value;
        return this;
    }

    /**
     * If you want to learn about the sync process, you can provide a listener here. For instance, a
     * {@link DownloadProgressTracker} is a good choice. This has no effect unless setBlockingStartup(false) has been called
     * too, due to some missing implementation code.
     */
    public WalletAppKit setDownloadListener(DownloadProgressTracker listener) {
        Objects.requireNonNull(listener);
        this.downloadListener = listener;
        return this;
    }

    /** If true, will register a shutdown hook to stop the library. Defaults to true. */
    public WalletAppKit setAutoStop(boolean autoStop) {
        this.autoStop = autoStop;
        return this;
    }

    /**
     * If set, the file is expected to contain a checkpoints file calculated with BuildCheckpoints. It makes initial
     * block sync faster for new users - please refer to the documentation on the bitcoinj website
     * (https://bitcoinj.github.io/speeding-up-chain-sync) for further details.
     */
    public WalletAppKit setCheckpoints(InputStream checkpoints) {
        if (this.checkpoints != null)
            Closeables.closeQuietly(checkpoints);
        this.checkpoints = Objects.requireNonNull(checkpoints);
        return this;
    }

    /**
     * If true (the default) then the startup of this service won't be considered complete until the network has been
     * brought up, peer connections established and the block chain synchronised. Therefore {@link #awaitRunning()} can
     * potentially take a very long time. If false, then startup is considered complete once the network activity
     * begins and peer connections/block chain sync will continue in the background.
     */
    public WalletAppKit setBlockingStartup(boolean blockingStartup) {
        this.blockingStartup = blockingStartup;
        return this;
    }

    /**
     * Sets the string that will appear in the subver field of the version message.
     * @param userAgent A short string that should be the name of your app, e.g. "My Wallet"
     * @param version A short string that contains the version number, e.g. "1.0-BETA"
     */
    public WalletAppKit setUserAgent(String userAgent, String version) {
        this.userAgent = Objects.requireNonNull(userAgent);
        this.version = Objects.requireNonNull(version);
        return this;
    }

    /**
     * Sets a wallet factory which will be used when the kit creates a new wallet.
     * @param walletFactory Factory for making new wallets (Use {@link WalletProtobufSerializer.WalletFactory#DEFAULT} for default behavior)
     * @return WalletAppKit for method chaining purposes
     */
    public WalletAppKit setWalletFactory(@Nonnull WalletProtobufSerializer.WalletFactory walletFactory) {
        Objects.requireNonNull(walletFactory);
        this.walletFactory = walletFactory;
        return this;
    }

    /**
     * If a seed is set here then any existing wallet that matches the file name will be renamed to a backup name,
     * the chain file will be deleted, and the wallet object will be instantiated with the given seed instead of
     * a fresh one being created. This is intended for restoring a wallet from the original seed. To implement restore
     * you would shut down the existing appkit, if any, then recreate it with the seed given by the user, then start
     * up the new kit. The next time your app starts it should work as normal (that is, don't keep calling this each
     * time).
     */
    public WalletAppKit restoreWalletFromSeed(DeterministicSeed seed) {
        this.restoreFromSeed = seed;
        return this;
    }

    /**
     * If an account key is set here then any existing wallet that matches the file name will be renamed to a backup name,
     * the chain file will be deleted, and the wallet object will be instantiated with the given key instead of
     * a fresh seed being created. This is intended for restoring a wallet from an account key. To implement restore
     * you would shut down the existing appkit, if any, then recreate it with the key given by the user, then start
     * up the new kit. The next time your app starts it should work as normal (that is, don't keep calling this each
     * time).
     */
    public WalletAppKit restoreWalletFromKey(DeterministicKey accountKey) {
        this.restoreFromKey = accountKey;
        return this;
    }

    /**
     * Sets the peer discovery class to use. If none is provided then DNS is used, which is a reasonable default.
     */
    public WalletAppKit setDiscovery(@Nullable PeerDiscovery discovery) {
        this.discovery = discovery;
        return this;
    }

    /**
     * <p>Override this to return wallet extensions if any are necessary.</p>
     *
     * <p>When this is called, chain(), store(), and peerGroup() will return the created objects, however they are not
     * initialized/started.</p>
     */
    protected List<WalletExtension> provideWalletExtensions() throws Exception {
        return Collections.emptyList();
    }

    /**
     * This method is invoked on a background thread after all objects are initialised, but before the peer group
     * or block chain download is started. You can tweak the objects configuration here.
     */
    protected void onSetupCompleted() { }

    /**
     * Tests to see if the spvchain file has an operating system file lock on it. Useful for checking if your app
     * is already running. If another copy of your app is running and you start the appkit anyway, an exception will
     * be thrown during the startup process. Returns false if the chain file does not exist or is a directory.
     */
    public boolean isChainFileLocked() throws IOException {
        RandomAccessFile file2 = null;
        try {
            File file = chainStoreFile();
            if (!file.exists())
                return false;
            if (file.isDirectory())
                return false;
            file2 = new RandomAccessFile(file, "rw");
            FileLock lock = file2.getChannel().tryLock();
            if (lock == null)
                return true;
            lock.release();
            return false;
        } finally {
            if (file2 != null)
                file2.close();
        }
    }

    @Override
    protected void startUp() throws Exception {
        // Runs in a separate thread.
        if (!directory.exists()) {
            if (!directory.mkdirs()) {
                throw new IOException("Could not create directory " + directory.getAbsolutePath());
            }
        }
        log.info("Starting up with directory = {}", directory);

        File chainFile = chainStoreFile();
        boolean chainFileExists = chainFile.exists();
        vWalletFile = new File(directory, filePrefix + ".wallet");
        // The new FullPruned database starts at genesis. Preserve the existing wallet's transactions
        // while clearing only its last-seen marker so the wallet can be replayed against verified blocks.
        // Do not force-reset the wallet: that would discard pending transactions during the SPV-to-full migration.
        boolean shouldReplayWallet = !fullPrunedValidation &&
                ((vWalletFile.exists() && !chainFileExists) || restoreFromSeed != null || restoreFromKey != null);
        vWallet = createOrLoadWallet(shouldReplayWallet);

        int fullPrunedRollbackTargetHeight = -1;
        if (fullPrunedValidation) {
            vFullPrunedStore = new SQLiteFullPrunedBlockStore(params, chainFile);
            File historyBuildingMarker = fullPrunedHistoryBuildingMarker();
            boolean historyReady = fullPrunedHistoryIndexMarker != null && fullPrunedHistoryIndexMarker.exists();
            boolean historyBuildInProgress = historyBuildingMarker != null && historyBuildingMarker.exists();
            boolean storeResetDuringOpen = ((SQLiteFullPrunedBlockStore) vFullPrunedStore).wasResetDuringOpen();
            // Start the one-time detail-index rebuild only when neither the ready nor building marker
            // exists. During an interrupted rebuild, keep the committed chain/index state and resume.
            boolean startHistoryIndexRebuild = fullPrunedHistoryIndexMarker != null
                    && !historyReady && !historyBuildInProgress;
            boolean resetWalletMarker = !chainFileExists || storeResetDuringOpen
                    || restoreFromSeed != null || restoreFromKey != null;
            boolean resetFullPrunedStore = !chainFileExists || storeResetDuringOpen
                    || restoreFromSeed != null || restoreFromKey != null || startHistoryIndexRebuild
                    || forceFullPrunedHistoryIndexRebuild;
            if (restoreFromSeed != null || restoreFromKey != null || startHistoryIndexRebuild
                    || forceFullPrunedHistoryIndexRebuild) {
                // These are explicit replay cases. Persist the building marker BEFORE clearing
                // SQLite, so Android force-stop cannot leave a cleared store with no resume marker.
                beginFullPrunedHistoryIndexBuildBeforeReset();
                ((SQLiteFullPrunedBlockStore) vFullPrunedStore).clear();
                resetWalletMarker = true;
                resetFullPrunedStore = true;
            } else if (storeResetDuringOpen) {
                // The store constructor already initialized a mismatched/corrupt ruleset at genesis.
                // Do not clear that fresh store a second time; only persist the history rebuild marker
                // and reset the wallet's checkpoint to match the initialized chainstate.
                beginFullPrunedHistoryIndexBuildBeforeReset();
                resetWalletMarker = true;
                resetFullPrunedStore = true;
            } else {
                StoredBlock verifiedHead = vFullPrunedStore.getVerifiedChainHead();
                int walletHeight = vWallet.getLastBlockSeenHeight();
                Sha256Hash walletHash = vWallet.getLastBlockSeenHash();
                boolean walletBehindStore = verifiedHead.getHeight() > 0 &&
                        (walletHeight < verifiedHead.getHeight() ||
                                (walletHeight == verifiedHead.getHeight() &&
                                        (walletHash == null || !walletHash.equals(verifiedHead.getHeader().getHash()))));
                if (walletBehindStore) {
                    // A force-stop can persist the SQLite block/UTXO transaction just before the
                    // wallet autosave persists its last-seen marker. Never clear a valid, advanced
                    // chainstate merely because those two durable files are a few blocks apart.
                    // If the wallet checkpoint is still on this branch, roll back only to that point
                    // using retained undo data, then normal P2P sync replays just the missing range.
                    // If undo is already pruned or the checkpoint is not an ancestor, preserve the
                    // verified store and report the condition rather than silently restarting genesis.
                    int rollbackDistance = walletHeight >= 0
                            ? verifiedHead.getHeight() - walletHeight : Integer.MAX_VALUE;
                    // WalletAppKit constructs SQLiteFullPrunedBlockStore with its default 2,880-block
                    // undo window. Don't walk hundreds of thousands of StoredBlocks when that undo
                    // range could not possibly cover the gap.
                    if (walletHeight >= 0 && walletHash != null
                            && rollbackDistance > 0 && rollbackDistance <= 2880
                            && isWalletCheckpointAncestor(vFullPrunedStore, verifiedHead, walletHeight, walletHash)) {
                        fullPrunedRollbackTargetHeight = walletHeight;
                        log.warn("Wallet checkpoint {} is behind Full Pruned verified tip {}; will attempt an undo-backed rollback to resume safely",
                                walletHeight, verifiedHead.getHeight());
                    } else {
                        log.warn("Wallet checkpoint {} does not match or is too far behind the verified Full Pruned tip {} for safe undo rollback. Preserving chainstate; no genesis reset will be performed",
                                walletHeight, verifiedHead.getHeight());
                    }
                }
            }
            if (fullPrunedHistoryIndexMarker != null) {
                if (resetFullPrunedStore || (historyBuildInProgress && !historyReady)) {
                    // If any reset/replay occurs, the ready marker must be revoked until catch-up.
                    if (fullPrunedHistoryIndexMarker.exists() && !fullPrunedHistoryIndexMarker.delete())
                        throw new IOException("Could not revoke stale Full Pruned history ready marker: " + fullPrunedHistoryIndexMarker);
                    File markerParent = historyBuildingMarker.getParentFile();
                    if (markerParent != null && !markerParent.exists()
                            && !markerParent.mkdirs() && !markerParent.isDirectory())
                        throw new IOException("Could not create Full Pruned history marker directory: " + markerParent);
                    if (!historyBuildingMarker.exists() && !historyBuildingMarker.createNewFile()
                            && !historyBuildingMarker.exists())
                        throw new IOException("Could not persist Full Pruned history building marker: " + historyBuildingMarker);
                } else if (historyBuildingMarker != null && historyBuildingMarker.exists()
                        && fullPrunedHistoryIndexMarker.exists()) {
                    // The ready marker is the commit point if a crash occurred before building-marker cleanup.
                    if (!historyBuildingMarker.delete())
                        log.warn("Could not remove stale Full Pruned history building marker: {}", historyBuildingMarker);
                }
            }
            if (resetWalletMarker) {
                vWallet.setLastBlockSeenHash(null);
                vWallet.setLastBlockSeenHeight(-1);
                vWallet.clearLastBlockSeenTime();
                vWallet.saveToFile(vWalletFile);
            }
            vStore = null;
            vChain = new FullPrunedBlockChain(params, vFullPrunedStore);
            if (fullPrunedRollbackTargetHeight >= 0) {
                try {
                    ((FullPrunedBlockChain) vChain).rollbackToHeight(fullPrunedRollbackTargetHeight);
                    log.info("Full Pruned chainstate rolled back only to wallet checkpoint {}; the verified history before that point was preserved",
                            fullPrunedRollbackTargetHeight);
                } catch (BlockStoreException rollbackFailure) {
                    // Undo data is retained only for a bounded reorg window. On failure the store's
                    // batch is aborted atomically; keep the valid current tip rather than clearing it.
                    log.warn("Could not roll back Full Pruned store to wallet checkpoint {} because undo data is unavailable or invalid. Preserving existing chainstate and resuming from its verified tip",
                            fullPrunedRollbackTargetHeight, rollbackFailure);
                }
            }
        } else {
            vStore = new SPVBlockStore(params, chainFile);
            if (!chainFileExists || restoreFromSeed != null || restoreFromKey != null) {
                if (checkpoints == null && !PlatformUtils.isAndroidRuntime()) {
                    checkpoints = CheckpointManager.openStream(params);
                }

                if (checkpoints != null) {
                    // Initialize the chain file with a checkpoint to speed up first-run sync.
                    Instant time;
                    if (restoreFromSeed != null) {
                        time = restoreFromSeed.getCreationTime().orElse(Instant.EPOCH);
                        if (chainFileExists) {
                            log.info("Clearing the chain file in preparation for restore.");
                            ((SPVBlockStore) vStore).clear();
                        }
                    } else if (restoreFromKey != null) {
                        time = restoreFromKey.getCreationTime().orElse(Instant.EPOCH);
                        if (chainFileExists) {
                            log.info("Clearing the chain file in preparation for restore.");
                            ((SPVBlockStore) vStore).clear();
                        }
                    } else {
                        time = vWallet.earliestKeyCreationTime();
                    }
                    if (time.isAfter(Instant.EPOCH))
                        CheckpointManager.checkpoint(params, checkpoints, (SPVBlockStore) vStore, time);
                    else
                        log.warn("Creating a new uncheckpointed block store due to a wallet with a creation time of zero: this will result in a very slow chain sync");
                } else if (chainFileExists) {
                    log.info("Clearing the chain file in preparation for restore.");
                    ((SPVBlockStore) vStore).clear();
                }
            }
            vChain = new BlockChain(network, vStore);
        }

        // UTXOProvider is a runtime association and is not serialized with Wallet. In Full Pruned
        // mode, make bitcoinj's spend-candidate and AVAILABLE_SPENDABLE balance calculations use
        // the globally verified UTXO set. Explicitly detach it in SPV mode.
        vWallet.setUTXOProvider(fullPrunedValidation ? vFullPrunedStore : null);

        // The wallet file and a chain-store file can legitimately be at different heights when the
        // user changes between Lite/SPV and FullPruned validation. Never let a stale wallet marker
        // suppress callbacks for blocks arriving from the selected chain. Preserve wallet transactions.
        if (vWallet.getLastBlockSeenHeight() > vChain.getBestChainHeight()) {
            log.warn("Wallet last-seen height {} is ahead of selected chain height {}; resetting only the wallet's block marker for forward replay",
                    vWallet.getLastBlockSeenHeight(), vChain.getBestChainHeight());
            vWallet.setLastBlockSeenHash(null);
            vWallet.setLastBlockSeenHeight(-1);
            vWallet.clearLastBlockSeenTime();
            vWallet.saveToFile(vWalletFile);
        }

        vPeerGroup = createPeerGroup();
        // Full validation from genesis requires archival block bodies including witness data.
        // Supplying these service bits to the discovery call lets Signet DNS seeds return filtered
        // x9 peers. Keep custom discovery sources intact; the requirements also apply at handshake.
        if (fullPrunedValidation && network != BitcoinNetwork.REGTEST) {
            vPeerGroup.setRequiredServicesForPeerConnections(
                    Services.NODE_NETWORK | Services.NODE_WITNESS);
        }
        if (this.userAgent != null)
            vPeerGroup.setUserAgent(userAgent, version);

        // Set up peer addresses or discovery first, so if wallet extensions try to broadcast a transaction
        // before we're actually connected the broadcast waits for an appropriate number of connections.
        if (peerAddresses != null) {
            for (PeerAddress addr : peerAddresses) vPeerGroup.addAddress(addr);
            vPeerGroup.setMaxConnections(peerAddresses.length);
            peerAddresses = null;
        } else if (params.network() != BitcoinNetwork.REGTEST) {
            vPeerGroup.addPeerDiscovery(discovery != null ? discovery : new DnsDiscovery(network));
        }
        vChain.addWallet(vWallet);
        vPeerGroup.addWallet(vWallet);

        // vChain, vWallet, and vPeerGroup all initialized; allow subclass (if any) a chance to adjust configuration
        onSetupCompleted();

        // Start the PeerGroup (asynchronously) and start downloading the blockchain (asynchronously)
        vPeerGroup.startAsync().whenComplete((result, t) -> {
            if (t == null) {
                vPeerGroup.startBlockChainDownload(downloadListener);
            } else {
                throw new RuntimeException(t);
            }
        });

        // Make sure we shut down cleanly.
        installShutdownHook();

        if (blockingStartup) {
            downloadListener.await();   // Wait for the blockchain to download
        }
    }

    private Wallet createOrLoadWallet(boolean shouldReplayWallet) throws Exception {
        Wallet wallet;

        maybeMoveOldWalletOutOfTheWay();

        if (vWalletFile.exists()) {
            wallet = loadWallet(shouldReplayWallet);
        } else {
            wallet = createWallet();
            wallet.freshReceiveKey();
            for (WalletExtension e : provideWalletExtensions()) {
                wallet.addExtension(e);
            }

            // Currently the only way we can be sure that an extension is aware of its containing wallet is by
            // deserializing the extension (see WalletExtension#deserializeWalletExtension(Wallet, byte[]))
            // Hence, we first save and then load wallet to ensure any extensions are correctly initialized.
            wallet.saveToFile(vWalletFile);
            wallet = loadWallet(false);
        }

        if (useAutoSave) {
            this.setupAutoSave(wallet);
        }

        return wallet;
    }

    protected void setupAutoSave(Wallet wallet) {
        wallet.autosaveToFile(vWalletFile, Duration.ofSeconds(5), null);
    }

    private Wallet loadWallet(boolean shouldReplayWallet) throws Exception {
        WalletExtension[] extensions = provideWalletExtensions().toArray(new WalletExtension[0]);
        return Wallet.loadFromFile(vWalletFile, walletFactory, shouldReplayWallet, false, extensions );
    }

    protected Wallet createWallet() {
        KeyChainGroup.Builder kcg = KeyChainGroup.builder(network, structure);
        if (restoreFromSeed != null)
            kcg.fromSeed(restoreFromSeed, preferredOutputScriptType);
        else if (restoreFromKey != null)
            kcg.fromKey(restoreFromKey, preferredOutputScriptType).build();
        else
            kcg.fromRandom(preferredOutputScriptType);

        return walletFactory.create(network, kcg.build());
    }

    private void maybeMoveOldWalletOutOfTheWay() {
        if (restoreFromSeed == null && restoreFromKey == null) return;
        if (!vWalletFile.exists()) return;
        int counter = 1;
        File newName;
        do {
            newName = new File(vWalletFile.getParent(), "Backup " + counter + " for " + vWalletFile.getName());
            counter++;
        } while (newName.exists());
        log.info("Renaming old wallet file {} to {}", vWalletFile, newName);
        if (!vWalletFile.renameTo(newName)) {
            // This should not happen unless something is really messed up.
            throw new RuntimeException("Failed to rename wallet for restore");
        }
    }

    protected PeerGroup createPeerGroup() {
        return new PeerGroup(network, vChain);
    }

    private void installShutdownHook() {
        if (autoStop) {
            Runtime.getRuntime().addShutdownHook(new Thread(this::shutdownHook, "shutdownHook"));
        }
    }

    private void shutdownHook() {
        try {
            stopAsync();
            awaitTerminated();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected void shutDown() throws Exception {
        // Runs in a separate thread.
        try {
            vPeerGroup.stop();
            if (vChain instanceof FullPrunedBlockChain) {
                ((FullPrunedBlockChain) vChain).shutdownScriptVerificationExecutor();
            }
            vWallet.saveToFile(vWalletFile);
            if (vFullPrunedStore != null) {
                vFullPrunedStore.close();
                vFullPrunedStore = null;
            } else if (vStore != null) {
                vStore.close();
            }

            vPeerGroup = null;
            vWallet = null;
            vStore = null;
            vFullPrunedStore = null;
            vChain = null;
        } catch (BlockStoreException e) {
            throw new IOException(e);
        }
    }

    /**
     * Close and release resources. Implements {@link Closeable}. This should be idempotent.
     */
    @Override
    public void close() {
        stopAsync();
        awaitTerminated();
    }

    public BitcoinNetwork network() {
        return network;
    }

    public NetworkParameters params() {
        return params;
    }

    public AbstractBlockChain chain() {
        checkState(state() == State.STARTING || state() == State.RUNNING, () ->
                "cannot call until startup is complete");
        return vChain;
    }

    public BlockStore store() {
        checkState(state() == State.STARTING || state() == State.RUNNING, () ->
                "cannot call until startup is complete");
        return fullPrunedValidation ? vFullPrunedStore : vStore;
    }

    public FullPrunedBlockStore fullPrunedStore() {
        checkState(state() == State.STARTING || state() == State.RUNNING, () -> "cannot call until startup is complete");
        return vFullPrunedStore;
    }

    public boolean isFullPrunedValidationEnabled() {
        return fullPrunedValidation;
    }

    /** True only when the wallet-scoped Full Pruned input-history index has committed ready. */
    public boolean isFullPrunedHistoryIndexReady() {
        if (!fullPrunedValidation || fullPrunedHistoryIndexMarker == null) return false;
        File building = fullPrunedHistoryBuildingMarker();
        File failed = fullPrunedHistoryFailureMarker();
        return fullPrunedHistoryIndexMarker.exists()
                && (building == null || !building.exists())
                && (failed == null || !failed.exists());
    }

    private File chainStoreFile() {
        return new File(directory, filePrefix + (fullPrunedValidation ? ".fullpruned.sqlite" : ".spvchain"));
    }

    public Wallet wallet() {
        checkState(state() == State.STARTING || state() == State.RUNNING, () ->
                "cannot call until startup is complete");
        return vWallet;
    }

    public PeerGroup peerGroup() {
        checkState(state() == State.STARTING || state() == State.RUNNING, () ->
                "cannot call until startup is complete");
        return vPeerGroup;
    }

    public File directory() {
        return directory;
    }
}
